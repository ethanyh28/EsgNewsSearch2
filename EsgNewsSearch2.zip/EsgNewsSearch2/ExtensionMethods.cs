﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;
using System.Windows.Forms;
using System.Drawing;
using System.Runtime.InteropServices;

namespace ExtensionMethods
{
    public static class MyExtensions
    {
        [DllImport("kernel32")]
        //private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);
        public static extern bool WritePrivateProfileString(byte[] section, byte[] key, byte[] val, string filePath);

        [DllImport("kernel32")]
        //private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);
        public static extern int GetPrivateProfileString(byte[] section, byte[] key, byte[] def, byte[] retVal, int size, string filePath);

        public static string Right(this string s, int length)
        {
            length = Math.Max(length, 0);

            if (s.Length > length)
            {
                return s.Substring(s.Length - length, length);
            }
            else
            {
                return s;
            }
        }


        /// <summary>
        ///  IV (對稱演算法的初始化向量)和Key(金鑰)
        /// </summary>

        /// 第一組加密金鑰 for real time Encrypt
        public static string strKey = "ethanlin"; //一定要有8碼
        public static string strIV = "ethanlin";
        /// 第一組加密金鑰
        /// 
        /// 第二組加密金鑰 for OralceDB login Encrypt
        public static string strKey1 = "25236470"; //一定要有8碼
        public static string strIV1 = "ethanlin";
        /// 第二組加密金鑰
        
        /// <summary>
        ///  加密
        /// </summary>
        /// <param name ="_strQ"></param>>
        /// <returns></returns>>
        /// 

        /// 第一組加密金鑰
        public static string Encrypt(string _strQ)
        {

            byte[] buffer = Encoding.UTF8.GetBytes(_strQ);
            MemoryStream ms = new MemoryStream();
            DESCryptoServiceProvider tdes = new DESCryptoServiceProvider();

            CryptoStream encStream = new CryptoStream(ms, tdes.CreateEncryptor(Encoding.UTF8.GetBytes(strKey), Encoding.UTF8.GetBytes(strIV)), CryptoStreamMode.Write);
            encStream.Write(buffer, 0, buffer.Length);
            encStream.FlushFinalBlock();
            return Convert.ToBase64String(ms.ToArray()).Replace("+", "%");
        }

        /// <summary>
        ///  解密
        /// </summary>
        /// <param name ="_strQ"></param>>
        /// <returns></returns>>

        public static string Decrypt(string _strQ)
        {
            _strQ = _strQ.Replace("%", "+");
            byte[] buffer = Convert.FromBase64String(_strQ);

            MemoryStream ms = new MemoryStream();
            DESCryptoServiceProvider tdes = new DESCryptoServiceProvider();

            CryptoStream encStream = new CryptoStream(ms, tdes.CreateDecryptor(Encoding.UTF8.GetBytes(strKey), Encoding.UTF8.GetBytes(strIV)), CryptoStreamMode.Write);
            encStream.Write(buffer, 0, buffer.Length);
            encStream.FlushFinalBlock();
            return Encoding.UTF8.GetString(ms.ToArray());
        }
        /// 第一組加密金鑰
        /// 第二組加密金鑰
        public static string Encrypt1(string _strQ)
        {

            byte[] buffer = Encoding.UTF8.GetBytes(_strQ);
            MemoryStream ms = new MemoryStream();
            DESCryptoServiceProvider tdes = new DESCryptoServiceProvider();

            CryptoStream encStream = new CryptoStream(ms, tdes.CreateEncryptor(Encoding.UTF8.GetBytes(strKey1), Encoding.UTF8.GetBytes(strIV1)), CryptoStreamMode.Write);
            encStream.Write(buffer, 0, buffer.Length);
            encStream.FlushFinalBlock();
            return Convert.ToBase64String(ms.ToArray()).Replace("+", "%");
        }

        /// <summary>
        ///  解密
        /// </summary>
        /// <param name ="_strQ"></param>>
        /// <returns></returns>>

        public static string Decrypt1(string _strQ)
        {
            _strQ = _strQ.Replace("%", "+");
            byte[] buffer = Convert.FromBase64String(_strQ);

            MemoryStream ms = new MemoryStream();
            DESCryptoServiceProvider tdes = new DESCryptoServiceProvider();

            CryptoStream encStream = new CryptoStream(ms, tdes.CreateDecryptor(Encoding.UTF8.GetBytes(strKey1), Encoding.UTF8.GetBytes(strIV1)), CryptoStreamMode.Write);
            encStream.Write(buffer, 0, buffer.Length);
            encStream.FlushFinalBlock();
            return Encoding.UTF8.GetString(ms.ToArray());
        }
        /// 第二組加密金鑰

        //Textbox hint function  
        public static void Init(this TextBox textBox, string prompt)
        {
            textBox.Text = prompt;
            bool wma = true;
            textBox.ForeColor = Color.Gray;
            textBox.GotFocus += (source, ex) =>
            {
                if (((TextBox)source).ForeColor == Color.Black)
                    return;
                if (wma)
                {
                    wma = false;
                    textBox.Text = "";
                    textBox.ForeColor = Color.Black;
                }
            };

            textBox.LostFocus += (source, ex) =>
            {
                TextBox t = ((TextBox)source);
                if (t.Text.Length == 0)
                {
                    t.Text = prompt;
                    t.ForeColor = Color.Gray;
                    return;
                }
                if (!wma && string.IsNullOrEmpty(textBox.Text))
                {
                    wma = true;
                    textBox.Text = prompt;
                    textBox.ForeColor = Color.Gray;
                }
            };
            textBox.TextChanged += (source, ex) =>
            {
                if (((TextBox)source).Text.Length > 0)
                {
                    textBox.ForeColor = Color.Black;
                }
            };
        }

        //讀取ini read & write utf8
        private static byte[] getBytes(string s, string encodingName)
        {
            return null == s ? null : Encoding.GetEncoding(encodingName).GetBytes(s);
        }

        public static string ReadString(string section, string key, string def, string fileName, string encodingName = "utf-8", int size = 1024)
        {
            byte[] buffer = new byte[size];
            int count = GetPrivateProfileString(getBytes(section, encodingName), getBytes(key, encodingName), getBytes(def, encodingName), buffer, size, fileName);
            return Encoding.GetEncoding(encodingName).GetString(buffer, 0, count).Trim();
        }

        public static bool WriteString(string section, string key, string value, string fileName, string encodingName = "utf-8")
        {
            return WritePrivateProfileString(getBytes(section, encodingName), getBytes(key, encodingName), getBytes(value, encodingName), fileName);
        }
        //讀取ｉni,read & write utf8
    }
}
