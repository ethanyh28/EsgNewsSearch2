﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using HtmlAgilityPack;
using HtmlDocument = HtmlAgilityPack.HtmlDocument;
using System.Reflection;
using System.Runtime.InteropServices;
using OpenQA.Selenium ;
using OpenQA.Selenium.PhantomJS ;
using OpenQA.Selenium.Chrome ;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using ExtensionMethods ;

//using Google.APPI.Search;

namespace EsgNewsSearch2
{


    public partial class F_EsgNewsSearch2 : Form
    {
        //loading 簡繁體中文轉換
        [DllImport("kernel32", CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int LCMapString(int Locale, int dwMapFlags, string lpSrcStr, int cchSrc, [Out] string lpDestStr, int cchDest);

        //[DllImport("user32.dll", CharSet = CharSet.Auto)]
        //static extern IntPtr FindWindow(IntPtr hwnd, string title);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        static extern int PostMessage(IntPtr hwnd, int msg, uint wParam, uint lParam);

        //public const int WM_CLOSE = 0x10; //關閉命令
        //public const int WM_KEYDOWN = 0x0100;//按下鍵
        //public const int WM_KEYUP = 0x0101;//按鍵起來
        //public const int VK_RETURN = 0x0D;//Enter

        //讀取INI檔,檔案文字編碼必須使用 utf8 without BOM_Notepad++ 才可讀取字詞
        string dirstr = Application.StartupPath + "\\EsgNewsSearch2_utf8.ini";

        // 透過OS層的元件進行轉換的動作 
        public static string ConvertChinese(string strSource, CharsetType enumCharsetType)
        {
            String strTarget = new String(' ', strSource.Length);
            int tReturn = LCMapString((int)CharsetType.Default, (int)enumCharsetType, strSource, strSource.Length, strTarget, strSource.Length);
            return strTarget;
        }

        // 轉換的語系型別
        public enum CharsetType
        {
            Default = 0x0800,
            Simplified = 0x02000000,
            Traditional = 0x04000000,
        }

        private WebClient webClient = new WebClient();

        public string UpdateDate = "";

        public string go_flag = "Y";

        public string release_version = "", new_version = "" , SERVER_PATH = "" ;

        //建立 User agent list
        List<String> user_ag_list = new List<string>();
        

        //public DataTable dt = new DataTable();
        public string url = "";


        //Define Class to return news data
        public class ItemNews
        {
            public string searchword { get; set; }
            public string searchword_ID { get; set; }
            public string title { get; set; }
            public string link { get; set; }
            public string item_id { get; set; }
            public string PubDate { get; set; }
            public string Description { get; set; }
            public string Source { get; set; }
        }

        //建立資料源
        DataSet dsESG ;

        //建立資料表
        //System.Data.DataTable dtGoogleNews = new System.Data.DataTable("ns_news");
        System.Data.DataTable dtGoogleNews ;

        //MSSQL connection string 
        string connectionString = null;
        public SqlConnection cnn;
        string server_ = "";
        string database_ = "";
        string user_ = "";
        string password_ = "";
        string Str_err = "";

        SqlCommand cmd;
        string sql = null;

        //MSSQL 連結參數
        private void setSQL_info()
        {
            //組合資料庫 MSSQL
            database_ = "INVEST";
            //server_ = ExtensionMethods.MyExtensions.ReadString(database_ , "server_", "", dirstr);
            //user_ = ExtensionMethods.MyExtensions.ReadString(database_, "user_", "", dirstr);
            //password_ = ExtensionMethods.MyExtensions.ReadString(database_, "password_", "", dirstr);

            //connectionString = "Data Source=" + server_
            //                  + ";Initial Catalog=" + database_
            //                  + ";User ID=" + user_
            //                  + ";Password=" + ExtensionMethods.MyExtensions.Decrypt1(password_)
            //                  + ";connection timeout = 0 ";
        }

        //MSSQL 資料庫連結
        private void Connect_MSSQL()
        {

            if (cnn != null)
            {
                cnn.Close();
                cnn.ConnectionString = connectionString;
            }
            else
            {
                cnn = new SqlConnection(connectionString);
            }
            //cnn.Open();
        }

        //主程式
        public F_EsgNewsSearch2()
        {

            InitializeComponent();

            //程式正式開始
            if (ExtensionMethods.MyExtensions.ReadString("CONFIG", "Location", "", dirstr) != "")
            {
                comboBox1.SelectedIndex = Convert.ToInt32(ExtensionMethods.MyExtensions.ReadString("CONFIG", "Location", "", dirstr)); //地區別 //預設 2.台灣 
            }
            else
            {
                comboBox1.SelectedIndex = 2;
            }
            if (ExtensionMethods.MyExtensions.ReadString("CONFIG", "period", "", dirstr) != "")
            {
                comboBox2.SelectedIndex = Convert.ToInt32(ExtensionMethods.MyExtensions.ReadString("CONFIG", "period", "", dirstr)); //時間 //傳送新聞期間預設 2.30天
            }
            else
            {
                comboBox2.SelectedIndex = 4;
            }
            if (ExtensionMethods.MyExtensions.ReadString("CONFIG", "searchword", "", dirstr) != "")
            {
                comboBox3.SelectedIndex = Convert.ToInt32(ExtensionMethods.MyExtensions.ReadString("CONFIG", "searchword", "", dirstr)); //預設 1.包含字詞
            }
            else
            {
                comboBox3.SelectedIndex = 1;
            }

            //選取parser 的方式
            if (ExtensionMethods.MyExtensions.ReadString("CONFIG", "Googlesearch", "", dirstr) != "")
            {
                comboBox4.SelectedIndex = Convert.ToInt32(ExtensionMethods.MyExtensions.ReadString("CONFIG", "Googlesearch", "", dirstr)); //0.100;1.10筆/頁;2.詳細
            }
            else
            {
                comboBox4.SelectedIndex = 1 ;
            }
            
                                                                                                                                       
            timer1.Enabled = true; //計時用
            timer1.Interval = 1000;
            tabControl1.SelectedIndex = 0; //初始值
            Build_DataSet(); //build a dataset
            setSQL_info();
            Connect_MSSQL();

        }

        //寫入TextBox
        private void write2text(string str)
        {
            textBox2.AppendText(str + System.Environment.NewLine);
        }

        //Googlenews_search1使用 news.google.com//使用 HtmlAgilityPack
        private void Googlenews_Search_request(List<String> chklist, int keyoption, string period, string lang)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                //查詢關鍵字迴圈
                foreach (string NewsParameters in chklist)
                {
                    //是否繼續查詢標記
                    if (go_flag == "Y")
                    {
                        //傳送網址
                        string url = "";
                        string RealSearchWord = "";
                        System.Data.DataTable dt = new System.Data.DataTable();

                        //傳送關鍵字-0.包含;1.完整
                        switch (keyoption)
                        {
                            case 0:
                                RealSearchWord = NewsParameters;
                                break;
                            case 1:
                                RealSearchWord = "\"" + NewsParameters + "\"";
                                break;
                        }

                        //設定時間變數
                        string Newperiod = "";
                        if (period == "過去24小時")
                        { Newperiod = " when:1d"; }
                        else if (period == "過去7天")
                        { Newperiod = " when:7d"; }
                        else if (period == "過去30天")
                        { Newperiod = " when:30d"; }
                        else if (period == "過去90天")
                        { Newperiod = " when:90d"; }
                        else if (period == "過去1年")
                        { Newperiod = " when:1y"; }
                        else if (period == "不限時間")
                        { Newperiod = ""; }

                        //選擇查詢國家
                        if (lang == "中國-中文")
                        {
                            url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=zh-CN&gl=CN&ceid=CN:zh-Hans";
                        }
                        else if (lang == "香港-中文")
                        {
                            url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=zh-HK&gl=HK&ceid=HK:zh-Hant";
                        }
                        else if (lang == "美國-英文")
                        {
                            url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=en-US&gl=US&ceid=US:en";
                        }
                        else if (lang == "日本-日文")
                        {
                            url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=ja&gl=JP&ceid=JP:ja";
                        }
                        else //台灣-中文
                        {
                            //網址轉碼
                            //url = Uri.EscapeUriString(url);
                            url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=zh-TW&gl=TW&ceid=TW:zh-Hant";
                        }

                        tb_url.Text = url;
                        toolStripStatusLabel5.Text = url;
                        toolStripStatusLabel6.Text = url;
                        Application.DoEvents();

                        List<ItemNews> Detail = new List<ItemNews>();

                        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

                        request.UserAgent = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36";
                        request.Accept = "text/html, application/xhtml+xml, */*";
                        request.Method = "GET";

                        HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                        if (response.StatusCode == HttpStatusCode.OK)
                        {
                            Stream receiveStream = response.GetResponseStream();
                            StreamReader readStream = null;

                            if (response.CharacterSet == "")
                            {
                                readStream = new StreamReader(receiveStream);
                            }
                            else
                            {
                                readStream = new StreamReader(receiveStream, Encoding.GetEncoding(response.CharacterSet));
                            }

                            //get news data in json string
                            string data = readStream.ReadToEnd();

                            //Declare Dataset for putting data in it.
                            DataSet ds = new DataSet();
                            StringReader reader = new StringReader(data);
                            ds.ReadXml(reader);
                            System.Data.DataTable dtGetNews = new System.Data.DataTable();

                            //drNews建立資料集Row
                            DataRow drNews;

                            int cnt = 1;
                            if (ds.Tables.Count > 3)
                            {
                                dtGetNews = ds.Tables["item"];

                                //開始查詢第一個公司
                                write2text("==" + comboBox3.Text + "== " + NewsParameters + " =====");
                                //寫入XML離線資料
                                foreach (DataRow dtRow in dtGetNews.Rows)
                                {
                                    //寫入google news 回訊
                                    ItemNews DataObj = new ItemNews();
                                    DataObj.searchword = NewsParameters;
                                    DataObj.title = dtRow["title"].ToString();
                                    DataObj.link = dtRow["link"].ToString();
                                    DataObj.item_id = dtRow["item_id"].ToString();
                                    DataObj.PubDate = dtRow["pubDate"].ToString();
                                    DataObj.Description = dtRow["description"].ToString();
                                    DataObj.Source = DataObj.title.Substring(DataObj.title.LastIndexOf(" - ") + 3);
                                    Detail.Add(DataObj);
                                    write2text(cnt.ToString() + ": " + "[" + DataObj.searchword + "]--" + DataObj.PubDate + "," + DataObj.Source + "," + DataObj.title);

                                    //寫入 dataset 
                                    DateTime oDate = Convert.ToDateTime(DataObj.PubDate);
                                    drNews = dtGoogleNews.NewRow();
                                    drNews["search_nm_"] = DataObj.searchword;
                                    drNews["title_"] = DataObj.title;
                                    drNews["link_"] = DataObj.link;
                                    drNews["pub_date_"] = oDate.Year.ToString("0000") + "年" + oDate.Month.ToString("00") + "月" + oDate.Day.ToString("00") + "日";
                                    drNews["desc_"] = DataObj.Description;
                                    drNews["media_"] = DataObj.Source;
                                    drNews["weight_"] = 0;
                                    drNews["match_word"] = "";
                                    dtGoogleNews.Rows.Add(drNews);

                                    cnt++;
                                }
                                //完成查詢
                                write2text("===== 查詢結束 ===== " + DateTime.Now.ToString());
                            }
                        }
                    }
                }

            }
            catch (Exception e)
            {
                MessageBox.Show("查詢忙碌,請稍侯再查詢 !!" + Environment.NewLine
                               + e.ToString());
                go_flag = "N"; //停止後續作業
                this.Cursor = Cursors.Default;
            }
            finally
            {
                this.Cursor = Cursors.Default;
                go_flag = "Y"; //停止後續作業                
            }
        }

        //使用 Selenium + PhantomJS XML
        private void Googlenews_Search_PhantomJS_xml(List<String> chklist, int keyoption, string period, string lang)
        {
            //建立 PhantomJS
            IWebDriver driver = new PhantomJSDriver(GetPhantomJSDriverService());

            //var chromeDriverService = ChromeDriverService.CreateDefaultService();
            //chromeDriverService.HideCommandPromptWindow = true;

            //var chromeOptions = new ChromeOptions();
            //chromeOptions.AddArguments("headless");

            //IWebDriver driver = new ChromeDriver(chromeDriverService, chromeOptions);
            //driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(10));

            Random random = new Random(Guid.NewGuid().GetHashCode()); //原理是利用Guid.NewGuid()每一次所產生出來的結果都是不同的，再利用它產生雜湊碼來當成亂數產生器的種子，產生出真的很亂的亂數。
            
            string tmpdt = "", tmpttl = "";
            int ran_record = 0;
            string after_day = ""; //查詢起始日
            string before_day = ""; //查詢截止日
            string NewsParameters = ""; //查詢關鍵字
            string NewsParameters_ID = ""; //查詢關鍵字ID

            try
            {
                //傳送網址
                string url = "";
                string RealSearchWord = "";

                this.Cursor = Cursors.WaitCursor;

                //查詢關鍵字迴圈
                foreach (String NewsParameters_ALL in chklist)
                {
                    //若有空字串不查
                    NewsParameters = NewsParameters_ALL;//查詢關鍵字
                    NewsParameters_ID = NewsParameters_ALL;//查詢關鍵字ID
                    if ( NewsParameters.Trim().ToString() != "")
                    {
                        //是否繼續查詢標記
                        if (go_flag == "Y")
                        {
                            //傳送關鍵字-0.包含;1.完整
                            switch (keyoption)
                            {
                                case 0:
                                    RealSearchWord = System.Net.WebUtility.UrlEncode(NewsParameters);
                                    break;
                                case 1:
                                    RealSearchWord = System.Net.WebUtility.UrlEncode("\"" + NewsParameters + "\"");
                                    break;
                            }

                            //設定時間變數
                            string Newperiod = "";
                            if (period == "過去24小時")
                            { Newperiod = " when:1d"; }
                            else if (period == "過去7天")
                            { Newperiod = " when:7d"; }
                            else if (period == "過去30天")
                            { Newperiod = " when:30d"; }
                            else if (period == "過去90天")
                            { Newperiod = " when:90d"; }
                            else if (period == "過去1年")
                            { Newperiod = " when:1y"; }
                            else if (period == "不限時間")
                            { Newperiod = ""; }

                            //選擇查詢國家
                            //指定查詢區間
                            Newperiod = "after:2019/9/30 before:2020/9/30";

                            if (lang == "中國-中文")
                            {
                                url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=zh-CN&gl=CN&ceid=CN:zh-Hans";
                            }
                            else if (lang == "香港-中文")
                            {
                                url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=zh-HK&gl=HK&ceid=HK:zh-Hant";
                            }
                            else if (lang == "美國-英文")
                            {
                                url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=en-US&gl=US&ceid=US:en";
                            }
                            else if (lang == "日本-日文")
                            {
                                url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=ja&gl=JP&ceid=JP:ja";
                            }
                            else //台灣-中文
                            {
                                //網址轉碼
                                //url = Uri.EscapeUriString(url);
                                url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=zh-TW&gl=TW&ceid=TW:zh-Hant";
                            }
                            
                            tb_url.Text = url;
                            toolStripStatusLabel5.Text = url;
                            toolStripStatusLabel6.Text = toolStripStatusLabel5.Text;
                            Application.DoEvents();

                            List<ItemNews> Detail = new List<ItemNews>();

                            //前往查詢網址
                            driver.Navigate().GoToUrl(url);
                            //Declare Dataset for putting data in it.
                            DataSet ds = new DataSet();
                            StringReader reader = new StringReader(driver.PageSource);
                            ds.ReadXml(reader);
                            System.Data.DataTable dtGetNews = new System.Data.DataTable();

                            int cnt = 1;
                            //開始查詢第一個公司
                            write2text("==" + comboBox3.Text + "== " + NewsParameters + " =====");

                            if (ds.Tables.Count > 3)
                            {
                                dtGetNews = ds.Tables["item"];

                                //寫入XML離線資料
                                foreach (DataRow dtRow in dtGetNews.Rows)
                                {
                                    //寫入google news 回訊
                                    ItemNews DataObj = new ItemNews();
                                    DataObj.searchword = NewsParameters;
                                    DataObj.searchword_ID = NewsParameters_ID+"_ID" ;
                                    DataObj.title = dtRow["title"].ToString();
                                    DataObj.link = dtRow["link"].ToString();
                                    DataObj.item_id = dtRow["item_id"].ToString();
                                    DataObj.PubDate = dtRow["pubDate"].ToString();
                                    DataObj.Description = dtRow["description"].ToString();
                                    DataObj.Source = DataObj.title.Substring(DataObj.title.LastIndexOf(" - ") + 3);
                                    Detail.Add(DataObj);
                                    write2text(cnt.ToString() + ": " + "[" + DataObj.searchword + "]--" + DataObj.PubDate + "," + DataObj.Source + "," + DataObj.title);

                                    //寫入 dataset 
                                    if (DataObj.PubDate != "")
                                    {
                                        // DataGrid
                                        //drNews建立資料集Row
                                        DataRow drNews;
                                        DateTime oDate = Convert.ToDateTime(DataObj.PubDate);
                                        drNews = dtGoogleNews.NewRow();
                                        drNews["date_"] = "20200930";
                                        drNews["search_id_"] = DataObj.searchword_ID;
                                        drNews["search_nm_"] = DataObj.searchword;
                                        drNews["title_"] = DataObj.title;
                                        drNews["link_"] = DataObj.link;
                                        if (DataObj.PubDate != "")
                                        { drNews["pub_date_"] = oDate.Year.ToString("0000") + "年" + oDate.Month.ToString("00") + "月" + oDate.Day.ToString("00") + "日"; }
                                        else
                                        { drNews["pub_date_"] = DateTime.Today.Year.ToString("0000") + "年" + DateTime.Today.Month.ToString("00") + "月" + DateTime.Today.Day.ToString("00") + "日"; }
                                        drNews["desc_"] = DataObj.Description;
                                        drNews["media_"] = DataObj.Source;
                                        drNews["weight_"] = 0;
                                        drNews["match_word"] = "";
                                        dtGoogleNews.Rows.Add(drNews);
                                    }
                                    cnt++;
                                }
                                //完成查詢
                                write2text("===== 查詢結束 ===== " + DateTime.Now.ToString());
                            }
                            else
                            {
                                write2text("===== 查無符合新聞 ===== " + DateTime.Now.ToString());
                            }
                            //if (ds.Tables.Count > 3)

                            //增加查詢暫緩時間 random 
                            ran_record = random.Next(5, 20);
                            Thread.Sleep(ran_record * random.Next(1000, 1500));
                        }
                    }                      
                }
            }
            catch (Exception e)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("查詢錯誤,請稍侯再查詢 !!" + Environment.NewLine
                               + e.ToString() + Environment.NewLine
                               );
                go_flag = "N"; //停止後續作業
            }
            finally
            {
                driver.Close();
                driver.Dispose();
                go_flag = "Y"; //停止後續作業
                this.Cursor = Cursors.Default;
            }
        }

        //使用 Selenium + Chrome HTML 20200713改版
        private void Googlenews_Search_Chrome_html_20200713(List<String> chklist, int keyoption, string period, string lang, int Googlesearch)
        {
            //使用 profilesIni()
            //D:\\Users\\002523\\AppData\\Local\\Google\\Chrome\\User Data\\Default
            //string profiles = "D:\\Users\\002523\\AppData\\Local\\Google\\Chrome\\User Data\\Default";
            Random random = new Random(Guid.NewGuid().GetHashCode()); //原理是利用Guid.NewGuid()每一次所產生出來的結果都是不同的，再利用它產生雜湊碼來當成亂數產生器的種子，產生出真的很亂的亂數。

            //UA list 0~10
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.14 Safari/537.36");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.36 Safari/537.36");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.105 Safari/537.36");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.16 Safari/537.36");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.11 Safari/537.36");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/81.0.4044.69 Safari/537.11");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:2.0b13pre) Gecko/20110307 Firefox/4.0b13pre");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.1");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.30 Safari/537.36");

            //建立 ChromeDriver
            var chromeDriverService = ChromeDriverService.CreateDefaultService();
            chromeDriverService.HideCommandPromptWindow = true;


            var chromeOptions = new ChromeOptions();

            //隨機提供user agent header
            string useragent = user_ag_list[random.Next(0, 10)] ;
            //string useragent = user_ag_list[11];

            if (checkBox3.Checked)
            { chromeOptions.AddArguments(new List<string>() { "no-sandbox", "disable-gpu" , useragent }); }//, "incognito" 
            else
            { chromeOptions.AddArguments(new List<string>() { "headless", "no-sandbox", "disable-gpu" , useragent }); }//, "incognito" 

            //每次執行前先刪除之前掛掉沒在用的chrome, chromedriver的process
            //KillUncontrollerBrowser();
            IWebDriver driver = new ChromeDriver(chromeDriverService, chromeOptions);
            //IWebDriver driver = new ChromeDriver(chromeDriverService);

            try
            {
                //傳送網址
                string url = "";
                string RealSearchWord = "";
                System.Data.DataTable dt = new System.Data.DataTable();

                int ran_record = 0;

                string go_next = "Y";

                this.Cursor = Cursors.WaitCursor;                
                //查詢關鍵字迴圈
                foreach (string NewsParameters in chklist)
                {
                    if (go_next == "ROBOT_BLOCK")
                    {
                        break;
                    }
                    //若有空字串不查
                    if (NewsParameters.Trim().ToString() != "" )
                    {
                        //是否繼續查詢標記
                        if (go_flag == "Y")
                        {
                            //傳送關鍵字-0.包含;1.完整
                            switch (keyoption)
                            {
                                case 0:
                                    //RealSearchWord = System.Net.WebUtility.UrlEncode(NewsParameters);
                                    RealSearchWord = NewsParameters ;
                                    break;
                                case 1:
                                    //RealSearchWord = System.Net.WebUtility.UrlEncode("\"" + NewsParameters + "\"");
                                    RealSearchWord = "\"" + NewsParameters + "\"";
                                    break;
                            }

                            //設定時間變數
                            string Newperiod = "";
                            if (period == "過去24小時")
                            { Newperiod = "&tbs=qdr:d"; }
                            else if (period == "過去7天")
                            { Newperiod = "&tbs=qdr:d7"; }
                            else if (period == "過去30天")
                            { Newperiod = "&tbs=qdr:m"; }
                            else if (period == "過去90天")
                            { Newperiod = "&tbs=qdr:m3"; }
                            else if (period == "過去1年")
                            { Newperiod = "&tbs=qdr:y"; }
                            else if (period == "不限時間")
                            { Newperiod = ""; }

                            //選擇查詢國家
                            string v_lang = "";
                            if ((lang == "中國-中文") || (lang == "香港-中文"))
                            {
                                v_lang = "&lr=lang_zh-CN|lang_zh-TW";
                            }
                            else if (lang == "美國-英文")
                            {
                                v_lang = "&lr=lang_en";
                            }
                            else if (lang == "日本-日文")
                            {
                                v_lang = "&lr=lang_ja";
                            }
                            else //台灣-中文
                            {
                                //網址轉碼
                                v_lang = "&lr=lang_zh-CN|lang_zh-TW";
                            }
                            
                            //開始查詢第一個公司
                            write2text("==" + comboBox3.Text + "== " + NewsParameters + " =====");

                            this.Cursor = Cursors.WaitCursor;
                            List<ItemNews> Detail = new List<ItemNews>();

                            try
                            {
                                //string searchword = "台積電";
                                //driver.Manage().Window.Size = new Size(1280, 720);
                                //string url = Uri.EscapeUriString("https://www.google.com/search?q=台積電&tbm=nws&start=0");
                                //driver.Navigate().GoToUrl(url);

                                int page_number = 1;
                                int start_no = 0;

                                while (go_next == "Y")
                                {
                                    if (page_number == 1)
                                    {
                                        start_no = (page_number - 1) * 10;
                                        //string url = Uri.EscapeUriString("https://www.google.com/search?q=" + searchword + "&tbm=nws&Ccd_min:4/1/2020&Ccd_max:6/14/2020&start=" + start_no);
                                        url = Uri.EscapeUriString("https://www.google.com/search?q=" + RealSearchWord + "&tbm=nws" + Newperiod +  v_lang); //"&start=" + start_no +
                                        driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(20));
                                        driver.Navigate().GoToUrl(url);
                                        //改為
                                        //url = Uri.EscapeUriString("https://www.google.com/"); //"&start=" + start_no +
                                        //driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(15));
                                        //driver.Navigate().GoToUrl(url);
                                        //Thread.Sleep(random.Next(15, 30) * 1000);
                                    }

                                   
                                    tb_url.Text = driver.Url ;
                                    toolStripStatusLabel5.Text = driver.Url ;
                                    toolStripStatusLabel6.Text = toolStripStatusLabel5.Text;
                                    Application.DoEvents();

                                    //讀取"result status"
                                    if (driver.PageSource.IndexOf("找不到符合") != -1)
                                    {
                                        go_next = "N";
                                    }
                                    else if (driver.PageSource.IndexOf("為何顯示此頁") != -1)
                                    {
                                        go_next = "ROBOT_BLOCK";
                                    }
                                    else
                                    {
                                        //寫入新聞資訊                    
                                        string xpath_str = "";
                                        IList<IWebElement> g = driver.FindElements(By.ClassName("g"));
                                        write2text("===第" + page_number.ToString() + "頁,共" + g.Count.ToString() + "條===" + ran_record.ToString());
                                        if (g.Count != 0)
                                        {
                                            for (int i = 1; i <= g.Count; i++)
                                            {
                                                //write2text("第" + i.ToString() + "條" + Environment.NewLine);
                                                //title
                                                xpath_str = "//*[@id='rso']/div[" + i + "]/div/div[1]/h3/a";
                                                IWebElement a = driver.FindElement(By.XPath(xpath_str));
                                                //write2text("Title:" + a.Text + Environment.NewLine);
                                                //link
                                                //write2text("link:" + a.GetAttribute("href") + Environment.NewLine);
                                                //media
                                                xpath_str = "//*[@id='rso']/div[" + i + "]/div/div[1]/div[1]/span[1]";
                                                IWebElement a1 = driver.FindElement(By.XPath(xpath_str));
                                                //write2text("media:" + a1.Text + Environment.NewLine);
                                                //pubdate
                                                xpath_str = "//*[@id='rso']/div[" + i + "]/div/div[1]/div[1]/span[3]";
                                                IWebElement a2 = driver.FindElement(By.XPath(xpath_str));
                                                // 進行當日發布新聞日期調整
                                                string pubdate = "";
                                                if (a2.Text.IndexOf("前") > -1)
                                                {
                                                    //write2text("date:" + DateTime.Today.ToString("yyyy年MM月dd日") + Environment.NewLine);
                                                    pubdate = DateTime.Today.ToString("yyyy年MM月dd日");
                                                }
                                                else
                                                {
                                                    //write2text("date:" + a2.Text + Environment.NewLine);
                                                    pubdate = a2.Text;
                                                }
                                                //desc
                                                xpath_str = "//*[@id='rso']/div[" + i + "]/div/div/div[2]";
                                                IWebElement a3 = driver.FindElement(By.XPath(xpath_str));
                                                //write2text("desc:" + a3.Text + Environment.NewLine + Environment.NewLine);

                                                //寫入 List<ItemNews> Detail
                                                ItemNews DataObj = new ItemNews();
                                                DataObj.searchword = NewsParameters;
                                                DataObj.title = a.Text;
                                                DataObj.link = a.GetAttribute("href");
                                                DataObj.item_id = "";
                                                DataObj.PubDate = pubdate;
                                                DataObj.Description = a3.Text;
                                                DataObj.Source = a1.Text;
                                                Detail.Add(DataObj);
                                                write2text(page_number.ToString() + "-" + i.ToString() + ": " + "[" + DataObj.searchword + "]--" + DataObj.PubDate + "," + DataObj.Source + "," + DataObj.title);
                                                //寫入 dataset 
                                                if (DataObj.PubDate != "")
                                                {
                                                    //drNews建立資料集Row
                                                    DateTime oDate = Convert.ToDateTime(DataObj.PubDate);
                                                    DataRow drNews;
                                                    drNews = dtGoogleNews.NewRow();
                                                    drNews["search_nm_"] = DataObj.searchword;
                                                    drNews["title_"] = DataObj.title;
                                                    drNews["link_"] = DataObj.link;
                                                    if (DataObj.PubDate != "")
                                                    {
                                                        drNews["pub_date_"] = oDate.Year.ToString("0000") + "年" + oDate.Month.ToString("00") + "月" + oDate.Day.ToString("00") + "日";
                                                    }
                                                    //drNews["pub_date_"] = DataObj.PubDate;
                                                    drNews["desc_"] = DataObj.Description;
                                                    drNews["media_"] = DataObj.Source;
                                                    drNews["weight_"] = 0;
                                                    drNews["match_word"] = "";
                                                    dtGoogleNews.Rows.Add(drNews);
                                                }

                                                // parser type 2 詳細
                                                if (Googlesearch == 2)
                                                {
                                                    //附掛新聞: YiHbdc
                                                    xpath_str = "//*[@id='rso']/div[" + i + "]";
                                                    IList<IWebElement> g1 = driver.FindElement(By.XPath(xpath_str)).FindElements(By.ClassName("YiHbdc"));
                                                    for (int j = 1; j <= g1.Count; j++)
                                                    {
                                                        //write2text("第" + i.ToString() + "條之 " + j.ToString() + Environment.NewLine);
                                                        //title
                                                        xpath_str = "//*[@id='rso']/div[" + i + "]/div/div[" + (j * 2) + "]/a";
                                                        IWebElement card = driver.FindElement(By.XPath(xpath_str));
                                                        //write2text("Title:" + card.Text + Environment.NewLine);
                                                        //link
                                                        //write2text("link:" + card.GetAttribute("href") + Environment.NewLine);
                                                        //media
                                                        xpath_str = "//*[@id='rso']/div[" + i + "]/div/div[" + (j * 2) + "]/span[1]";
                                                        IWebElement card1 = driver.FindElement(By.XPath(xpath_str));
                                                        //write2text("media:" + card1.Text + Environment.NewLine);
                                                        //pubdate
                                                        xpath_str = "//*[@id='rso']/div[" + i + "]/div/div[" + (j * 2) + "]/span[3]";
                                                        IWebElement card2 = driver.FindElement(By.XPath(xpath_str));
                                                        // 進行當日發布新聞日期調整
                                                        if (card2.Text.IndexOf("前") > -1)
                                                        {
                                                            //write2text("date:" + DateTime.Today.ToString("yyyy年MM月dd日") + Environment.NewLine);
                                                            pubdate = DateTime.Today.ToString("yyyy年MM月dd日");
                                                        }
                                                        else
                                                        {
                                                            //write2text("pubdate:" + card2.Text + Environment.NewLine);
                                                            pubdate = card2.Text;
                                                        }
                                                        //desc
                                                        //textBox2.AppendText("desc:" + card.Text + Environment.NewLine + Environment.NewLine);

                                                        //寫入 List<ItemNews> Detail
                                                        DataObj.searchword = NewsParameters;
                                                        DataObj.title = card.Text;
                                                        DataObj.link = card.GetAttribute("href");
                                                        DataObj.item_id = "";
                                                        DataObj.PubDate = pubdate;
                                                        DataObj.Description = card.Text;
                                                        DataObj.Source = card1.Text;
                                                        Detail.Add(DataObj);
                                                        write2text(page_number.ToString() + "-" + i.ToString() + "-" + j.ToString() + ": "
                                                                   + "[" + DataObj.searchword + "]--" + DataObj.PubDate + "," + DataObj.Source + "," + DataObj.title);
                                                        //寫入 dataset 
                                                        if (DataObj.PubDate != "")
                                                        {
                                                            //drNews建立資料集Row
                                                            DateTime oDate = Convert.ToDateTime(DataObj.PubDate);
                                                            DataRow drNews;
                                                            drNews = dtGoogleNews.NewRow();
                                                            drNews["search_nm_"] = DataObj.searchword;
                                                            drNews["title_"] = DataObj.title;
                                                            drNews["link_"] = DataObj.link;
                                                            if (DataObj.PubDate != "")
                                                            {
                                                                drNews["pub_date_"] = oDate.Year.ToString("0000") + "年" + oDate.Month.ToString("00") + "月" + oDate.Day.ToString("00") + "日";
                                                            }
                                                            //drNews["pub_date_"] = DataObj.PubDate;
                                                            drNews["desc_"] = DataObj.Description;
                                                            drNews["media_"] = DataObj.Source;
                                                            drNews["weight_"] = 0;
                                                            drNews["match_word"] = "";
                                                            dtGoogleNews.Rows.Add(drNews);
                                                        }
                                                    }

                                                    //附掛新聞: ErI7Gd
                                                    xpath_str = "//*[@id='rso']/div[" + i + "]";
                                                    IList<IWebElement> g2 = driver.FindElement(By.XPath(xpath_str)).FindElements(By.ClassName("ErI7Gd"));
                                                    for (int k = 1; k <= g2.Count; k++)
                                                    {
                                                        //write2text("第" + i.ToString() + "條之 " + (k + g1.Count).ToString() + Environment.NewLine);
                                                        //title
                                                        xpath_str = "//*[@id='rso']/div[" + i + "]/div/div[" + ((k + g1.Count) * 2) + "]/a";
                                                        IWebElement card = driver.FindElement(By.XPath(xpath_str));
                                                        //write2text("Title:" + card.Text + Environment.NewLine);
                                                        //link
                                                        //write2text("link:" + card.GetAttribute("href") + Environment.NewLine);
                                                        //media
                                                        xpath_str = "//*[@id='rso']/div[" + i + "]/div/div[" + ((k + g1.Count) * 2) + "]/span[3]";
                                                        IWebElement card1 = driver.FindElement(By.XPath(xpath_str));
                                                        //write2text("media:" + card1.Text + Environment.NewLine);
                                                        //pubdate
                                                        xpath_str = "//*[@id='rso']/div[" + i + "]/div/div[" + ((k + g1.Count) * 2) + "]/span[5]";
                                                        IWebElement card2 = driver.FindElement(By.XPath(xpath_str));
                                                        // 進行當日發布新聞日期調整 , 可能有三欄
                                                        if (card2.Text.IndexOf("前") > -1)
                                                        {
                                                            //write2text("date:" + DateTime.Today.ToString("yyyy年MM月dd日") + Environment.NewLine);
                                                            pubdate = DateTime.Today.ToString("yyyy年MM月dd日");
                                                        }
                                                        else if ((card1.Text.IndexOf("前") > -1) || (card1.Text.IndexOf("年") > -1))
                                                        {
                                                            //write2text("pubdate:" + card2.Text + Environment.NewLine);
                                                            pubdate = card2.Text;
                                                        }
                                                        //desc
                                                        //write2text("desc:" + card.Text + Environment.NewLine);

                                                        //寫入 List<ItemNews> Detail
                                                        DataObj.searchword = NewsParameters;
                                                        DataObj.title = card.Text;
                                                        DataObj.link = card.GetAttribute("href");
                                                        DataObj.item_id = "";
                                                        DataObj.PubDate = pubdate;
                                                        DataObj.Description = card.Text;
                                                        DataObj.Source = card1.Text;
                                                        Detail.Add(DataObj);
                                                        write2text(page_number.ToString() + "-" + i.ToString() + "-" + (k + g1.Count).ToString() + ": "
                                                                   + "[" + DataObj.searchword + "]--" + DataObj.PubDate + "," + DataObj.Source + "," + DataObj.title);
                                                        //寫入 dataset 
                                                        if (DataObj.PubDate != "")
                                                        {
                                                            //drNews建立資料集Row
                                                            DateTime oDate = Convert.ToDateTime(DataObj.PubDate);
                                                            DataRow drNews;
                                                            drNews = dtGoogleNews.NewRow();
                                                            drNews["search_nm_"] = DataObj.searchword;
                                                            drNews["title_"] = DataObj.title;
                                                            drNews["link_"] = DataObj.link;
                                                            if (DataObj.PubDate != "")
                                                            {
                                                                drNews["pub_date_"] = oDate.Year.ToString("0000") + "年" + oDate.Month.ToString("00") + "月" + oDate.Day.ToString("00") + "日";
                                                            }
                                                            drNews["desc_"] = DataObj.Description;
                                                            drNews["media_"] = DataObj.Source;
                                                            drNews["weight_"] = 0;
                                                            drNews["match_word"] = "";
                                                            dtGoogleNews.Rows.Add(drNews);
                                                        }
                                                    }
                                                }
                                            }
                                            //Application.DoEvents();
                                        }
                                        else
                                        {
                                            go_next = "N"; //當查詢無資料時,不再進行查詢
                                        }

                                        //按下一頁
                                        if (driver.PageSource.IndexOf("下一頁") != -1)
                                        {
                                            IWebElement bt_next = driver.FindElement(By.XPath("//*[@id='pnnext']/span[2]"));
                                            bt_next.Click();
                                        }
                                        else if (driver.PageSource.IndexOf("為何顯示此頁") != -1)
                                        {
                                            go_next = "ROBOT_BLOCK";
                                        }
                                        else
                                        {
                                            go_next = "N"; //當查詢無資料時,不再進行查詢
                                        }

                                        page_number++;
                                        //休息秒鐘,再次頁查詢 
                                        ran_record = random.Next(5, 20);
                                        Thread.Sleep(ran_record * random.Next(1000, 1500));
                                        //if (page_number == 3)
                                        //{
                                        //    go_next = "N"; //測試用
                                        //}                                        
                                    }
                                };
                                if (go_next == "ROBOT_BLOCK")
                                {
                                    write2text("已被偵測為自動化程式,暫緩使用!!" + DateTime.Now.ToString() + Environment.NewLine);
                                }
                                else
                                {
                                    write2text("[" + RealSearchWord + "]查詢結束!!" + DateTime.Now.ToString() + Environment.NewLine);
                                    go_next = "Y";
                                }                                
                                Application.DoEvents();
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }                         
                        }
                    }
                }
            }
            catch (Exception e)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("查詢錯誤,請稍侯再查詢 !!" + Environment.NewLine
                               + e.ToString() + Environment.NewLine
                               );
                go_flag = "N"; //停止後續作業
            }
            finally
            {
                driver.Quit();
                driver.Dispose();
                go_flag = "Y"; //停止後續作業
                this.Cursor = Cursors.Default;
            }
        }

        //檢查Element存在
        private bool IsElementPresent(IWebDriver driver, By by)
        {
            try
            {
                driver.FindElement(by);
                return true;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        //使用 Selenium + Chrome HTML 
        private void Googlenews_Search_Chrome_html(List<String> chklist, int keyoption, string period, string lang, int Googlesearch)
        {
            //使用 profilesIni()
            //D:\\Users\\002523\\AppData\\Local\\Google\\Chrome\\User Data\\Default
            //string profiles = "D:\\Users\\002523\\AppData\\Local\\Google\\Chrome\\User Data\\Default";
            Random random = new Random(Guid.NewGuid().GetHashCode()); //原理是利用Guid.NewGuid()每一次所產生出來的結果都是不同的，再利用它產生雜湊碼來當成亂數產生器的種子，產生出真的很亂的亂數。

            //UA list 0~10
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.14 Safari/537.36");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.36 Safari/537.36");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.105 Safari/537.36");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.16 Safari/537.36");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.11 Safari/537.36");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/81.0.4044.69 Safari/537.11");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:2.0b13pre) Gecko/20110307 Firefox/4.0b13pre");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.1");
            user_ag_list.Add("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.30 Safari/537.36");

            //建立 ChromeDriver
            var chromeDriverService = ChromeDriverService.CreateDefaultService();
            chromeDriverService.HideCommandPromptWindow = true;


            var chromeOptions = new ChromeOptions();

            //隨機提供user agent header
            string useragent = user_ag_list[random.Next(0, 10)];
            //string useragent = user_ag_list[11];

            if (checkBox3.Checked)
            { chromeOptions.AddArguments(new List<string>() { "no-sandbox", "disable-gpu", useragent }); }//, "incognito" 
            else
            { chromeOptions.AddArguments(new List<string>() { "headless", "no-sandbox", "disable-gpu", useragent }); }//, "incognito" 

            //每次執行前先刪除之前掛掉沒在用的chrome, chromedriver的process
            //KillUncontrollerBrowser();
            IWebDriver driver = new ChromeDriver(chromeDriverService, chromeOptions);
            //IWebDriver driver = new ChromeDriver(chromeDriverService);

            try
            {
                //傳送網址
                string url = "";
                string RealSearchWord = "";
                System.Data.DataTable dt = new System.Data.DataTable();

                int ran_record = 0;

                string go_next = "Y";

                this.Cursor = Cursors.WaitCursor;
                //查詢關鍵字迴圈
                foreach (string NewsParameters in chklist)
                {
                    if (go_next == "ROBOT_BLOCK")
                    {
                        break;
                    }
                    //若有空字串不查
                    if (NewsParameters.Trim().ToString() != "")
                    {
                        //是否繼續查詢標記
                        if (go_flag == "Y")
                        {
                            //傳送關鍵字-0.包含;1.完整
                            switch (keyoption)
                            {
                                case 0:
                                    //RealSearchWord = System.Net.WebUtility.UrlEncode(NewsParameters);
                                    RealSearchWord = NewsParameters;
                                    break;
                                case 1:
                                    //RealSearchWord = System.Net.WebUtility.UrlEncode("\"" + NewsParameters + "\"");
                                    RealSearchWord = "\"" + NewsParameters + "\"";
                                    break;
                            }

                            //設定時間變數
                            string Newperiod = "";
                            if (period == "過去24小時")
                            { Newperiod = "&tbs=qdr:d"; }
                            else if (period == "過去7天")
                            { Newperiod = "&tbs=qdr:d7"; }
                            else if (period == "過去30天")
                            { Newperiod = "&tbs=qdr:m"; }
                            else if (period == "過去90天")
                            { Newperiod = "&tbs=qdr:m3"; }
                            else if (period == "過去1年")
                            { Newperiod = "&tbs=qdr:y"; }
                            else if (period == "不限時間")
                            { Newperiod = ""; }

                            //選擇查詢國家
                            string v_lang = "";
                            if ((lang == "中國-中文") || (lang == "香港-中文"))
                            {
                                v_lang = "&lr=lang_zh-CN|lang_zh-TW";
                            }
                            else if (lang == "美國-英文")
                            {
                                v_lang = "&lr=lang_en";
                            }
                            else if (lang == "日本-日文")
                            {
                                v_lang = "&lr=lang_ja";
                            }
                            else //台灣-中文
                            {
                                //網址轉碼
                                v_lang = "&lr=lang_zh-CN|lang_zh-TW";
                            }

                            //開始查詢第一個公司
                            write2text("==" + comboBox3.Text + "== " + NewsParameters + " =====");

                            this.Cursor = Cursors.WaitCursor;
                            List<ItemNews> Detail = new List<ItemNews>();

                            try
                            {
                                //string searchword = "台積電";
                                //driver.Manage().Window.Size = new Size(1280, 720);
                                //string url = Uri.EscapeUriString("https://www.google.com/search?q=台積電&tbm=nws&start=0");
                                //driver.Navigate().GoToUrl(url);

                                int page_number = 1;
                                int start_no = 0;                            

                                while (go_next == "Y")
                                {
                                    if (page_number == 1)
                                    {
                                        start_no = (page_number - 1) * 10;
                                        //string url = Uri.EscapeUriString("https://www.google.com/search?q=" + searchword + "&tbm=nws&Ccd_min:4/1/2020&Ccd_max:6/14/2020&start=" + start_no);
                                        url = Uri.EscapeUriString("https://www.google.com/search?q=" + RealSearchWord + "&tbm=nws" + Newperiod + v_lang); //"&start=" + start_no +
                                        driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(20));
                                        driver.Navigate().GoToUrl(url);
                                        //改為
                                        //url = Uri.EscapeUriString("https://www.google.com/"); //"&start=" + start_no +
                                        //driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(15));
                                        //driver.Navigate().GoToUrl(url);
                                        //Thread.Sleep(random.Next(15, 30) * 1000);
                                    }


                                    tb_url.Text = driver.Url;
                                    toolStripStatusLabel5.Text = driver.Url;
                                    toolStripStatusLabel6.Text = toolStripStatusLabel5.Text;
                                    Application.DoEvents();

                                    //讀取"result status"
                                    if (driver.PageSource.IndexOf("找不到符合") != -1)
                                    {
                                        go_next = "N";
                                    }
                                    else if (driver.PageSource.IndexOf("為何顯示此頁") != -1)
                                    {
                                        go_next = "ROBOT_BLOCK";
                                    }
                                    else
                                    {
                                        //寫入新聞資訊                    
                                        string xpath_str = "";
                                        IList<IWebElement> g = driver.FindElements(By.XPath("//*[@id='rso']/div"));
                                        write2text("===第" + page_number.ToString() + "頁,共" + g.Count.ToString() + "條===" + ran_record.ToString());
                                        if (g.Count != 0)
                                        {
                                            for (int i = 1; i <= g.Count; i++)
                                            {
                                                //write2text("第" + i.ToString() + "條" + Environment.NewLine);
                                                //宣告變數
                                                IWebElement a, a1, a2, a3, a4;
                                                string pubdate = "";
                                                int daysadj = 0;

                                                xpath_str = "//*[@id='rso']/div[" + i + "]/g-card/div/div/div[2]/a/div/div[2]/div[2]";
                                                if (IsElementPresent(driver, By.XPath(xpath_str)))//有圖片新聞
                                                {
                                                    //title                                                
                                                    xpath_str = "//*[@id='rso']/div[" + i + "]/g-card/div/div/div[2]/a/div/div[2]/div[2]";
                                                    a = driver.FindElement(By.XPath(xpath_str));

                                                    //media
                                                    xpath_str = "//*[@id='rso']/div[" + i + "]/g-card/div/div/div[2]/a/div/div[2]/div[1]";
                                                    a1 = driver.FindElement(By.XPath(xpath_str));

                                                    //pubdate
                                                    xpath_str = "//*[@id='rso']/div[" + i + "]/g-card/div/div/div[2]/a/div/div[2]/div[3]/div[2]/span/span/span";
                                                    a2 = driver.FindElement(By.XPath(xpath_str));
                                                    // 進行當日發布新聞日期調整
                                                    if (a2.Text.IndexOf("前") > -1)
                                                    {
                                                        if (a2.Text.IndexOf("天") > -1)
                                                        {
                                                            daysadj = a2.Text.IndexOf(" 天");
                                                            daysadj = Int32.Parse(a2.Text.Substring(0,daysadj)) * -1 ;
                                                            pubdate = DateTime.Today.AddDays(daysadj).ToString("yyyy年MM月dd日");
                                                        }
                                                        else
                                                        {
                                                            //write2text("date:" + DateTime.Today.ToString("yyyy年MM月dd日") + Environment.NewLine);
                                                            pubdate = DateTime.Today.ToString("yyyy年MM月dd日");
                                                        }
                                                    }
                                                    else
                                                    {
                                                        pubdate = a2.Text;
                                                    }
                                                    //desc
                                                    xpath_str = "//*[@id='rso']/div[" + i + "]/g-card/div/div/div[2]/a/div/div[2]/div[3]/div[1]";
                                                    a3 = driver.FindElement(By.XPath(xpath_str));

                                                    //link
                                                    xpath_str = "//*[@id='rso']/div[" + i + "]/g-card/div/div/div[2]/a";
                                                    a4 = driver.FindElement(By.XPath(xpath_str));

                                                }
                                                else //無圖片新聞
                                                {
                                                    //title   
                                                    xpath_str = "//*[@id='rso']/div[" + i + "]/g-card/div/div/div[2]/a/div/div[2]";
                                                    a = driver.FindElement(By.XPath(xpath_str));

                                                    //media
                                                    xpath_str = "//*[@id='rso']/div[" + i + "]/g-card/div/div/div[2]/a/div/div[1]";
                                                    a1 = driver.FindElement(By.XPath(xpath_str));

                                                    //pubdate
                                                    xpath_str = "//*[@id='rso']/div[" + i + "]/g-card/div/div/div[2]/a/div/div[3]/div[2]/span/span/span";
                                                    a2 = driver.FindElement(By.XPath(xpath_str));
                                                    // 進行當日發布新聞日期調整

                                                    if (a2.Text.IndexOf("天") > -1)
                                                    {
                                                        daysadj = a2.Text.IndexOf(" 天");
                                                        daysadj = Int32.Parse(a2.Text.Substring(0,daysadj)) * -1;
                                                        pubdate = DateTime.Today.AddDays(daysadj).ToString("yyyy年MM月dd日");
                                                    }
                                                    else
                                                    {
                                                        //write2text("date:" + DateTime.Today.ToString("yyyy年MM月dd日") + Environment.NewLine);
                                                        pubdate = DateTime.Today.ToString("yyyy年MM月dd日");
                                                    }
                                                    //desc
                                                    xpath_str = "//*[@id='rso']/div[" + i + "]/g-card/div/div/div[2]/a/div/div[3]/div[1]";
                                                    a3 = driver.FindElement(By.XPath(xpath_str));

                                                    //link
                                                    xpath_str = "//*[@id='rso']/div[" + i + "]/g-card/div/div/div[2]/a";
                                                    a4 = driver.FindElement(By.XPath(xpath_str));
                                                }


                                                //寫入 List<ItemNews> Detail
                                                ItemNews DataObj = new ItemNews();
                                                DataObj.searchword = NewsParameters;
                                                DataObj.title = a.Text;
                                                DataObj.link = a4.GetAttribute("href");
                                                DataObj.item_id = "";
                                                DataObj.PubDate = pubdate;
                                                DataObj.Description = a3.Text;
                                                DataObj.Source = a1.Text;
                                                Detail.Add(DataObj);
                                                write2text(page_number.ToString() + "-" + i.ToString() + ": " + "[" + DataObj.searchword + "]--" + DataObj.PubDate + "," + DataObj.Source + "," + DataObj.title);
                                                //寫入 dataset 
                                                if (DataObj.PubDate != "")
                                                {
                                                    //drNews建立資料集Row
                                                    DateTime oDate = Convert.ToDateTime(DataObj.PubDate);
                                                    DataRow drNews;
                                                    drNews = dtGoogleNews.NewRow();
                                                    drNews["search_nm_"] = DataObj.searchword;
                                                    drNews["title_"] = DataObj.title;
                                                    drNews["link_"] = DataObj.link;
                                                    if (DataObj.PubDate != "")
                                                    {
                                                        drNews["pub_date_"] = oDate.Year.ToString("0000") + "年" + oDate.Month.ToString("00") + "月" + oDate.Day.ToString("00") + "日";
                                                    }
                                                    //drNews["pub_date_"] = DataObj.PubDate;
                                                    drNews["desc_"] = DataObj.Description;
                                                    drNews["media_"] = DataObj.Source;
                                                    drNews["weight_"] = 0;
                                                    drNews["match_word"] = "";
                                                    dtGoogleNews.Rows.Add(drNews);
                                                }
                                            }
                                            //Application.DoEvents();
                                        }
                                        else
                                        {
                                            go_next = "N"; //當查詢無資料時,不再進行查詢
                                        }

                                        //按下一頁
                                        if (driver.PageSource.IndexOf("下一頁") != -1)
                                        {
                                            IWebElement bt_next = driver.FindElement(By.XPath("//*[@id='pnnext']/span[2]"));
                                            bt_next.Click();
                                        }
                                        else if (driver.PageSource.IndexOf("為何顯示此頁") != -1)
                                        {
                                            go_next = "ROBOT_BLOCK";
                                        }
                                        else
                                        {
                                            go_next = "N"; //當查詢無資料時,不再進行查詢
                                        }

                                        page_number++;
                                        //休息秒鐘,再次頁查詢 
                                        ran_record = random.Next(5, 20);
                                        Thread.Sleep(ran_record * random.Next(1000, 1500));
                                        //if (page_number == 2)
                                        //{
                                            //go_next = "N"; //測試用
                                        //}                                        
                                    }
                                };
                                if (go_next == "ROBOT_BLOCK")
                                {
                                    write2text("已被偵測為自動化程式,暫緩使用!!" + DateTime.Now.ToString() + Environment.NewLine);
                                }
                                else
                                {
                                    write2text("[" + RealSearchWord + "]查詢結束!!" + DateTime.Now.ToString() + Environment.NewLine);
                                    go_next = "Y";
                                }
                                Application.DoEvents();
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("查詢錯誤,請稍侯再查詢 !!" + Environment.NewLine
                               + e.ToString() + Environment.NewLine
                               );
                go_flag = "N"; //停止後續作業
            }
            finally
            {
                driver.Quit();
                driver.Dispose();
                go_flag = "Y"; //停止後續作業
                this.Cursor = Cursors.Default;
            }
        }

        //匯出Excel
        private void ExportExcel(string filename, DataGridView dgv)
        {
            
            string hyperlink = "";
            Microsoft.Office.Interop.Excel.Range tempRange;

            //改變鼠標樣式
            this.Cursor = Cursors.WaitCursor;
            Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();

            //有資料才匯出
            if (dgv.Rows.Count > 0)
            {
                string saveFileName = "";

                SaveFileDialog saveDialog = new SaveFileDialog();
                saveDialog.DefaultExt = "xlsx";
                saveDialog.Filter = "Excel檔案|*.xls;*.xlsx";
                saveDialog.FileName = filename;
                saveDialog.ShowDialog();
                saveFileName = saveDialog.FileName;

                //取消存檔
                if (saveFileName.IndexOf(":") < 0) 
                {
                    this.Cursor = Cursors.Default; //還原預設
                    return; 
                }
                
                if (xlApp == null)
                {
                    this.Cursor = Cursors.Default ;
                    MessageBox.Show("無法建立Excel物件,可能未安裝Excel!");
                    return;
                }

                Microsoft.Office.Interop.Excel.Workbooks workbooks = xlApp.Workbooks;
                Microsoft.Office.Interop.Excel.Workbook workbook = workbooks.Add(Microsoft.Office.Interop.Excel.XlWBATemplate.xlWBATWorksheet);
                Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Worksheets[1]; //取得sheet1

                //寫入列印日期
                worksheet.Cells[1, 1] = "列印日期:";                
                worksheet.Cells[1, 2] = DateTime.Today.Year.ToString("0000") + "年" + DateTime.Today.Month.ToString("00") + "月" + DateTime.Today.Day.ToString("00") + "日";
                worksheet.Cells[1, 2].Cells.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft; //置左
                
                //寫入標題
                for (int i = 0; i < dgv.ColumnCount ; i++)
                {
                    //排除寫入欄位
                    if (dgv.Columns[i].HeaderText != "大綱")
                    {
                        worksheet.Cells[1+1, i + 1] = dgv.Columns[i].HeaderText;
                        tempRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1 + 1, i + 1];
                        tempRange.Interior.Color = Color.LightGray ; //儲存格底色淡灰
                    }
                }

                //寫入數值
                for (int r = 0; r < dgv.Rows.Count; r++)
                {
                    for (int i = 0; i < dgv.ColumnCount ; i++)
                    {
                        //排除寫入欄位
                        if (dgv.Columns[i].HeaderText != "大綱" )
                        {
                            worksheet.Cells[r + 3, i + 1] = dgv.Rows[r].Cells[i].Value;
                            worksheet.Cells[r + 3, i + 1].ColumnWidth = 50;
                        }

                        //增加Hyperlink設定
                        if (dgv.Columns[i].HeaderText == "原始連結")
                        {
                            if (dgv.Rows[r].Cells[i].Value != null)
                            {
                                hyperlink = dgv.Rows[r].Cells[i].Value.ToString();
                                //Microsoft.Office.Interop.Excel.Range tempRange = worksheet.get_Range("E"+ (r+2).ToString(),Type.Missing); //使用英文加位置
                                //Microsoft.Office.Interop.Excel.Range tempRange = worksheet.get_Range(worksheet.Cells[r + 2, i + 1], worksheet.Cells[r + 2, i + 1]); //一個範圍
                                tempRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[r + 3, i + 1]; //一個儲存格
                                worksheet.Hyperlinks.Add(tempRange, hyperlink, Type.Missing, Type.Missing, Type.Missing); //加掛超連結
                            }
                        }
                    }
                    System.Windows.Forms.Application.DoEvents();
                }
                //欄位長度自動調整_use Range
                worksheet.Columns.EntireColumn.AutoFit();//
                ((Microsoft.Office.Interop.Excel.Range)worksheet.Columns["A",System.Type.Missing]).ColumnWidth = 10;
                ((Microsoft.Office.Interop.Excel.Range)worksheet.Columns["B", System.Type.Missing]).ColumnWidth = 15;
                ((Microsoft.Office.Interop.Excel.Range)worksheet.Columns["C", System.Type.Missing]).ColumnWidth = 13;
                ((Microsoft.Office.Interop.Excel.Range)worksheet.Columns["D", System.Type.Missing]).ColumnWidth = 33;
                ((Microsoft.Office.Interop.Excel.Range)worksheet.Columns["E", System.Type.Missing]).ColumnWidth = 50;
                ((Microsoft.Office.Interop.Excel.Range)worksheet.Columns["F", System.Type.Missing]).ColumnWidth = 7;
                ((Microsoft.Office.Interop.Excel.Range)worksheet.Columns["G", System.Type.Missing]).ColumnWidth = 10;
                //worksheet.Columns[0].EntireColumn.AutoFit();//開鍵字10
                //worksheet.Columns[1].EntireColumn.AutoFit();//發布時間15
                //worksheet.Columns[2].EntireColumn.AutoFit();//新聞來源13
                //worksheet.Columns[3].EntireColumn.AutoFit();//新聞標題33
                //worksheet.Columns[4].EntireColumn.AutoFit();//原始連結60
                //worksheet.Columns[5].EntireColumn.AutoFit();//合中數量7
                //worksheet.Columns[6].EntireColumn.AutoFit();//合中字詞10

                //預設Excel 列印格式
                //
                xlApp.PrintCommunication = false;
                Microsoft.Office.Interop.Excel.PageSetup pageSetup = worksheet.PageSetup;
                //FitPagesTall property 為 FIT, 使用 FittoPageswide 來縮放Worksheet　
                pageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                pageSetup.FitToPagesTall = false;
                pageSetup.FitToPagesWide = 1;
                xlApp.PrintCommunication = true;

                if (saveFileName != "")
                {
                    string v_openfife = "N";
                    try
                    {                        
                        workbook.SaveAs(saveFileName, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Missing.Value, Missing.Value, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange, Microsoft.Office.Interop.Excel.XlSaveConflictResolution.xlUserResolution, true, Missing.Value, Missing.Value, Missing.Value);
                        workbook.Saved = true;
                        workbook.Close();
                        
                        if (MessageBox.Show(filename + "儲存成功" + Environment.NewLine + "現在是否開啟檔案??", "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            v_openfife = "Y";
                        }
                    }
                    catch (Exception ex)
                    {
                        this.Cursor = Cursors.Default; //還原預設
                        //MessageBox.Show("匯出檔時錯誤,檔案可能正被開啟!\n" + ex.Message);
                    }
                    finally
                    {
                        xlApp.Quit();
                        GC.Collect();//強行釋放
                        this.Cursor = Cursors.Default; //還原預設
                    }
                    if (v_openfife =="Y") 
                    {
                        FileInfo fi = new FileInfo(saveFileName);
                        if (fi.Exists)
                        { System.Diagnostics.Process.Start(saveFileName); }
                    }
                }
                this.Cursor = Cursors.Default; //還原預設
            }
            else
            {
                this.Cursor = Cursors.Default; //還原預設
                MessageBox.Show("報表為空,無表格可匯出", "提示", MessageBoxButtons.OK);
            }
        }

        //建立暫存資料源
        private void Build_DataSet()
        {
            //建立資料源
            dsESG = new DataSet("NewsDB");

            //將Datatable加入資料源,以上取代此行
            //System.Data.DataTable dtGoogleNews = dsESG.Tables.Add("ns_news");
            dtGoogleNews = dsESG.Tables.Add("ns_news");

            //建立欄位
            //--查詢標的代碼 search_id_
            //dtGoogleNews.Columns.Add("search_id_", typeof(string));
            
            dtGoogleNews.Columns.Add("date_", typeof(string));
            dtGoogleNews.Columns["date_"].Caption = "查詢日期";
            //--查詢標的名稱GA_ID search_nm_
            dtGoogleNews.Columns.Add("search_id_", typeof(string));
            dtGoogleNews.Columns["search_id_"].Caption = "關鍵字ID";
            //--查詢標的名稱 search_nm_
            dtGoogleNews.Columns.Add("search_nm_", typeof(string));
            dtGoogleNews.Columns["search_nm_"].Caption = "關鍵字";
            //--發布日期 pub_date_
            dtGoogleNews.Columns.Add("pub_date_", typeof(string));
            dtGoogleNews.Columns["pub_date_"].Caption = "發布時間";
            //--來源媒體 media_
            dtGoogleNews.Columns.Add("media_", typeof(string));
            dtGoogleNews.Columns["media_"].Caption = "新聞來源";
            //--新聞標題 title_
            dtGoogleNews.Columns.Add("title_", typeof(string));
            dtGoogleNews.Columns["title_"].Caption = "新聞標題";
            //--來源連結 link_
            dtGoogleNews.Columns.Add("link_", typeof(string));
            dtGoogleNews.Columns["link_"].Caption = "原始連結";
            //--關鍵字權重 weight_
            dtGoogleNews.Columns.Add("weight_", typeof(decimal));
            //--關鍵字權重 weight_
            dtGoogleNews.Columns.Add("match_word", typeof(string));
            //--大綱 desc_
            dtGoogleNews.Columns.Add("desc_", typeof(string));
            dtGoogleNews.Columns["desc_"].Caption = "大綱";
            //--使用查詢語言 lang_
            dtGoogleNews.Columns.Add("lang_", typeof(string));
            dtGoogleNews.Columns["lang_"].Caption = "查詢語言";

            //--情緒正負向 sentiments_
            //dtGoogleNews.Columns.Add("sentiments_", typeof(string));
            //--異動日期 upd_date_
            //dtGoogleNews.Columns.Add("upd_date_", typeof(DateTime));
            //--異動者 upd_user_
            //dtGoogleNews.Columns.Add("upd_user_", typeof(string));


            //綁定至 dataGridView1
            dataGridView1.DataSource = dsESG;
            dataGridView1.DataMember = "ns_news";
            //dataGridView1.AutoGenerateColumns = false;
            //修改 dataGridView Caption & Hidden
            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            cellStyle.ForeColor = Color.Blue;
            cellStyle.SelectionForeColor = Color.Black;
            cellStyle.Font = new Font(FontFamily.GenericSansSerif, 10, FontStyle.Underline);

            dataGridView1.Columns[0].HeaderText = "查詢日期";
            dataGridView1.Columns[1].HeaderText = "關鍵字ID";
            //dataGridView1.Columns[0].Visible = false; //search_id_
            dataGridView1.Columns[2].HeaderText = "關鍵字";
            //dataGridView1.Columns[0].Resizable = DataGridViewTriState.NotSet ; 禁止使用者改變DataGridView1的第一列的列寬
            dataGridView1.Columns[3].HeaderText = "發布時間";
            //dataGridView1.Columns[1].Resizable = DataGridViewTriState.NotSet;
            dataGridView1.Columns[4].HeaderText = "新聞來源";
            dataGridView1.Columns[4].Width = 100;
            //dataGridView1.Columns[2].Resizable = DataGridViewTriState.NotSet;
            dataGridView1.Columns[5].HeaderText = "新聞標題";
            dataGridView1.Columns[5].Width = 500;
            //dataGridView1.Columns[3].Resizable = DataGridViewTriState.NotSet;
            dataGridView1.Columns[6].HeaderText = "原始連結";
            dataGridView1.Columns[6].DefaultCellStyle = cellStyle;
            dataGridView1.Columns[6].Width = 300;
            dataGridView1.Columns[7].HeaderText = "命中數量";
            dataGridView1.Columns[7].Width = 100;
            //dataGridView1.Columns[5].Resizable = DataGridViewTriState.NotSet;
            dataGridView1.Columns[8].HeaderText = "命中字詞";
            dataGridView1.Columns[8].Width = 200;
            //dataGridView1.Columns[6].Resizable = DataGridViewTriState.NotSet;
            dataGridView1.Columns[9].HeaderText = "大綱";
            dataGridView1.Columns[9].Visible = false; //desc_
            dataGridView1.Columns[10].HeaderText = "查詢語言";
            dataGridView1.Columns[10].Width = 200; ; //查詢語言
            //dataGridView1.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.False;
            //dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCellsExceptHeader ;   
        }

        //查詢google
        private void button1_Click(object sender, EventArgs e)
        {
            //url = @"http://www.taifex.com.tw/cht/5/stockMargining";
            //memoryStream = new MemoryStream(webClient.DownloadData(url));

            ////使用HtmlDocument.Load()進行編碼，使用UTF8編譯，取得整份網頁結構
            //HtmlDocument doc = new HtmlDocument();
            //doc.Load(memoryStream, Encoding.UTF8);

            //HtmlDocument docData = new HtmlDocument();
            //docData.LoadHtml(doc.DocumentNode.SelectSingleNode(@"//div[@name='printhere']").InnerHtml);

            ////獲得更新日期
            //UpdateDate = docData.DocumentNode.SelectSingleNode(@"/div/p/span").InnerText;

            ////從docData向下取得網頁上目標表格的html結構
            //HtmlDocument dt_html = new HtmlDocument();
            //dt_html.LoadHtml(docData.DocumentNode.SelectSingleNode(@"//table[@class='table_c']")
            //                                     .InnerHtml);
            ////批次取得th資料，利用這些資料進行IEnumarable創造dt的Column
            //HtmlNodeCollection headers = dt_html.DocumentNode.SelectNodes(@"//tbody/tr/th");

            //foreach (HtmlNode header in headers)
            //{
            //    dt.Columns.Add(header.InnerText);
            //    textBox2.AppendText(header.InnerText);
            //}

            ////可用rows取得所有列的資料，也可直接寫在foreach裡面，tr[td]的意思是選取「所有tr之下有td」的tr們
            ////HtmlNodeCollection rows = dt_html.DocumentNode.SelectNodes(@"//tr[td]");
            //foreach (HtmlNode row in dt_html.DocumentNode.SelectNodes(@"//tr[td]"))
            //{
            //    //再用SelectNodes批次取得所有td的資料，利用lambda語法取得所有InnerText
            //    dt.Rows.Add(row.SelectNodes(@"td").Select(td => td.InnerText.Trim()).ToArray());
            //}
            //textBox1.Text = UpdateDate;
            //dataGridView1.DataSource = new BindingSource(dt, null);
            //dataGridView1.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.False;
            //dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;


            //MessageBox.Show(textBox1.Text);
        }

        //查詢關鍵字
        private void button3_Click(object sender, EventArgs e)
        {
            string match_title_ = "", match_keyword = "", match_kword = "";

            string lng_negative = "", lng_governance = "", lng_Environmental = "", lng_social = "";

            tabControl1.SelectedIndex = 0;
            //符合負面關鍵字詞數量
            int match_cnt = 0;

            //符合複合關鍵字的新聞 flag
            string go_match_keyword = "N";

            //命中負面關鍵字詞筆數
            int match_Recordcount = 0;

            //讀取負面關鍵字預設值
            StringBuilder data = new StringBuilder(255);            

            if ( SearchWord.Text.IndexOf("輸入公司名稱:如台積電,大立光  公司請用','分隔") > -1 )
            {
                return;
            }

            switch (comboBox1.SelectedIndex)
            {
                case 1: //日文
                    lng_negative = "jp_negative";
                    lng_governance = "jp_governance";
                    lng_Environmental = "jp_Environmental";
                    lng_social = "jp_social";
                    break;
                case 3: //英文
                    lng_negative = "en_negative";
                    lng_governance = "en_governance";
                    lng_Environmental = "en_Environmental";
                    lng_social = "en_social";
                    break;
                default:
                    lng_negative = "zh_negative";
                    lng_governance = "zh_governance";
                    lng_Environmental = "zh_Environmental";
                    lng_social = "zh_social";
                    break;
            }

            //ESG檢查負面關鍵字
            string negative = "";

            //BAD WORD
            if (negative.Length == 0)
            { negative = ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_negative, "", dirstr); }
            else
            { negative = negative + "," + ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_negative, "", dirstr);  }

            //Governance
            if (negative.Length == 0)
            { negative = ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_governance, "", dirstr); }
            else
            { negative = negative + "," + ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_governance, "", dirstr); }

            //Environmental
            if (negative.Length == 0)
            { negative = ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_Environmental, "", dirstr); }
            else
            { negative = negative + "," + ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_Environmental, "", dirstr); }

            //social
            if (negative.Length == 0)
            { negative = ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_social, "", dirstr); }
            else
            { negative = negative + "," + ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_social, "", dirstr);  }


            //讀入ESG 關鍵字詞庫
            List<String> Checklist = new List<String>();
            if (SearchWord.Text != "")
            {
                Checklist = SearchWord.Text.Split(',').ToList();

                //保留查詢回訊
                if (checkBox1.Checked == false)
                {
                    //清除TextBon資料
                    textBox2.Clear();
                    //清除資料表
                    dtGoogleNews.Rows.Clear();
                }

                //parser 選擇
                switch (comboBox4.SelectedIndex)
                {
                    case 9 :
                        //使用 HtmlAgilityPack
                        Googlenews_Search_request(Checklist, comboBox3.SelectedIndex, comboBox2.SelectedItem.ToString(), comboBox1.Text);
                        break;
                    case 0: //快速
                        //使用 Selenium + PhantomJS output xml
                        Googlenews_Search_PhantomJS_xml(Checklist, comboBox3.SelectedIndex, comboBox2.SelectedItem.ToString(), comboBox1.Text);
                        break;
                    case 1: //標準
                    case 2: //慢速
                        //使用 Selenium + PhantomJS output parser html
                        Googlenews_Search_Chrome_html(Checklist, comboBox3.SelectedIndex, comboBox2.SelectedItem.ToString(), comboBox1.Text , comboBox4.SelectedIndex );
                        break;
                }

                //篩選有負面關鍵字的新聞
                if (checkBox2.Checked == true)
                {
                    //負面ESG關鍵字
                    List<String> KeywordList = new List<String>();

                    if (negative.Trim().Length > 0)
                    { KeywordList = negative.Split(',').ToList(); }

                    //遍歷原始新聞資料集
                    int total_cnt = dtGoogleNews.Rows.Count - 1;
                    for (int i = total_cnt; i >= 0; i--)
                    {
                        match_cnt = 0;
                        //中文依介面選項轉換繁體或簡體
                        switch (comboBox1.SelectedIndex)
                        {
                            case 0:// 簡體
                                match_title_ = ConvertChinese(dtGoogleNews.Rows[i]["title_"].ToString().ToUpper(), CharsetType.Simplified);
                                match_keyword = ConvertChinese(dtGoogleNews.Rows[i]["search_nm_"].ToString().ToUpper(), CharsetType.Simplified);
                                break;
                            case 4://香港中文
                            case 2:// 繁體
                                match_title_ = ConvertChinese(dtGoogleNews.Rows[i]["title_"].ToString().ToUpper(), CharsetType.Traditional);
                                match_keyword = ConvertChinese(dtGoogleNews.Rows[i]["search_nm_"].ToString().ToUpper(), CharsetType.Traditional);
                                break;
                            case 3:// 英文轉換統一大寫
                                match_title_ = dtGoogleNews.Rows[i]["title_"].ToString().ToUpper();
                                match_keyword = dtGoogleNews.Rows[i]["search_nm_"].ToString().ToUpper();
                                break;
                            default:
                                match_title_ = dtGoogleNews.Rows[i]["title_"].ToString().ToUpper();
                                match_keyword = dtGoogleNews.Rows[i]["search_nm_"].ToString().ToUpper();
                                break;
                        }

                        //處理複合關鍵字
                        write2text("===== 負面關鍵字檢查 ===== " + DateTime.Now.ToString());

                        go_match_keyword = "N";

                        List<String> ls_match_keyword = new List<String>();
                        ls_match_keyword = match_keyword.Split('+').ToList() ;
                        foreach (string mkeyword in ls_match_keyword)
                        {
                            if (match_title_.IndexOf(mkeyword) != -1)
                            {
                                go_match_keyword = "Y";
                            }
                        }                      

                        //當新聞title 包含複合關鍵字時 saved or remove
                        if  (go_match_keyword == "Y")
                        {
                            //MessageBox.Show(match_keyword + Environment.NewLine
                            //                                   + match_title_);
                            //比對符合多少負面關鍵字
                            foreach (string kword in KeywordList)
                            {
                                //負面關鍵字-中文依介面選項轉換繁體或簡體
                                switch (comboBox1.SelectedIndex)
                                {
                                    case 0:// 簡體
                                        match_kword = ConvertChinese(kword, CharsetType.Simplified);
                                        break;
                                    case 4:// 香港中文
                                    case 2:// 繁體
                                        match_kword = ConvertChinese(kword, CharsetType.Traditional);
                                        break;
                                    case 3:// 英文轉換統一大寫
                                        match_kword = kword ;
                                        break;
                                    default:
                                        match_kword = kword.ToUpper();
                                        break;
                                }

                                if (match_kword.Trim().ToString() != "")
                                {
                                    bool v_go;
                                    //移除掉非文字字元
                                    match_title_ = Regex.Replace(match_title_, @"[^\w\.@-]", " ",RegexOptions.None, TimeSpan.FromSeconds(1.5));

                                    switch (comboBox1.SelectedIndex)
                                    {
                                        case 3:// 英文判定單字相同才算配對
                                            v_go = Regex.IsMatch(match_title_, string.Format(@"\b{0}\b", match_kword), RegexOptions.IgnoreCase) ;
                                            break;
                                        default:
                                            v_go = match_title_.Contains(match_kword) ;
                                            break;
                                    }

                                    if (v_go)
                                    {
                                        match_cnt = match_cnt + 1;
                                        if (dtGoogleNews.Rows[i]["match_word"] == "")
                                        {  dtGoogleNews.Rows[i]["match_word"] = match_kword; }
                                        else
                                        {  dtGoogleNews.Rows[i]["match_word"] = dtGoogleNews.Rows[i]["match_word"] + "," + match_kword;  }
                                        
                                    }
                                }
                            }
                            // 無負面關鍵字
                            if (match_cnt == 0)
                            {
                                //MessageBox.Show("NoMatch:" + match_cnt.ToString() +":" + match_title_ );
                                //dtGoogleNews.Rows[i].Delete();                                
                            }
                            else
                            {
                                match_Recordcount = match_Recordcount + 1;
                                dtGoogleNews.Rows[i]["weight_"] = match_cnt;                                
                                //MessageBox.Show("Match:" + match_cnt.ToString() + ":"  + match_title_  ); 
                            }
                        }
                        else
                        {
                            //delete no match keyword record
                            dtGoogleNews.Rows[i].Delete();
                        }
                    }
                    write2text("===== 轉寫資料庫開始 ===== " + DateTime.Now.ToString());
                    dtGoogleNews.AcceptChanges();

                    if (dtGoogleNews.Rows.Count == 0)
                    {
                        if (textBox2.Text.IndexOf("偵測為自動化程式, 暫緩使用") == -1)
                        {
                            MessageBox.Show("查無符合新聞資訊");
                        }                        
                    }
                    else
                    {
                        MessageBox.Show("檢視新聞共 " + dtGoogleNews.Rows.Count.ToString("#,0") + " 筆" 
                                       + Environment.NewLine
                                       + "符合負面新聞共 " + match_Recordcount.ToString("#,0") + " 筆");
                        tabControl1.SelectedIndex = 1;
                    }
                }
                else
                {
                    MessageBox.Show("查詢新聞資訊共 " + dtGoogleNews.Rows.Count.ToString("#,0") + " 筆");
                    tabControl1.SelectedIndex = 1;
                }
            }
        }

        //控制查詢url-textbox
        private void label5_DoubleClick(object sender, EventArgs e)
        {

        }

        //Export Excel
        private void button2_Click(object sender, EventArgs e)
        {
            string vTime;
            string savefilename = "";
            vTime = DateTime.Today.Year.ToString("0000") + DateTime.Today.Month.ToString("00") + DateTime.Today.Day.ToString("00") ;
            if (SearchWord.Text.Trim() != "")
            {
                if (SearchWord.Text.IndexOf(",") == -1)
                {
                    savefilename = vTime + "_ESG新聞_" + SearchWord.Text.Substring(0, SearchWord.Text.Length );
                }
                else
                {
                    savefilename = vTime + "_ESG新聞_" + SearchWord.Text.Substring(0, SearchWord.Text.IndexOf(","));
                }
                ExportExcel(savefilename, dataGridView1);
            }
            else
            { MessageBox.Show("未輸入公司名稱查詢!!", "提示", MessageBoxButtons.OK); }
            
        }

        //Test filter 負面字樣
        private void button4_Click(object sender, EventArgs e)
        {
            //string match_searchword = "", match_lines = "", match_keyw = "";
            ////查詢關鍵字
            //List<String> searchList = new List<String>();
            //searchList = SearchWord.Text.Split(',').ToList();

            ////負面ESG關鍵字
            //List<String> KeywordList = new List<String>();
            //KeywordList = textBox1.Text.Split(',').ToList();

            ////關鍵字
            //foreach (string searchword in searchList)
            //{
                
            //    //MessageBox.Show(ConvertChinese(searchword, CharsetType.Default) + Environment.NewLine +
            //    //                ConvertChinese(searchword, CharsetType.Simplified) + Environment.NewLine +
            //    //                ConvertChinese(searchword, CharsetType.Traditional) + Environment.NewLine
            //    //               );
            //    match_searchword = ConvertChinese(searchword, CharsetType.Traditional);
            //    //新聞條文清單
            //    foreach (string lines in textBox3.Lines)
            //    {
            //        //檢查新聞標題中是否包含關鍵字,若有才進入負面關鍵字檢查
            //        match_lines = ConvertChinese(lines, CharsetType.Traditional);
            //        if (match_lines.IndexOf(searchword) != -1)
            //        {
            //            //檢查負面關鍵字
            //            foreach (string keyw in KeywordList)
            //            {
            //                match_keyw = ConvertChinese(keyw, CharsetType.Traditional);
            //                if (match_lines.IndexOf(keyw) != -1)
            //                {
            //                    MessageBox.Show(lines);
            //                }
            //            }
            //        }
            //    }
            //}

   
            //所有新聞
            //foreach (string value in Checklist)
            //{

            //}
        }

        //執行hyperlinks
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string cellstr = "";
            if (e.RowIndex == -1) return; //按到headertext 無效

            if (e.ColumnIndex == 4)
            {
                cellstr = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                //MessageBox.Show(cellstr);
                //use browser 
                string url = string.Format(cellstr);
                System.Diagnostics.Process.Start(url);
            }
        }

        //　建立PhantomJSDriverService
        private static PhantomJSDriverService GetPhantomJSDriverService()
        {
            PhantomJSDriverService pds = PhantomJSDriverService.CreateDefaultService();
            //Hide Console
            pds.HideCommandPromptWindow = true;
            //設置代理服務器地址
            //pds.Proxy = $"{ip}:{port}";
            //設置poxry 認證資訊
            //pds.ProxyAuthentication = GetProxyAuthorization();
            return pds;
        }

        //測試
        private async void button5_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            var chromeDriverService = ChromeDriverService.CreateDefaultService();
            chromeDriverService.HideCommandPromptWindow = true;

            var chromeOptions = new ChromeOptions();
            chromeOptions.AddArguments("headless");

            IWebDriver driver = new ChromeDriver(chromeDriverService, chromeOptions);
            driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(10));

            Application.UseWaitCursor = true;
            try
            {
                string searchword = "台積電";
                //driver.Manage().Window.Size = new Size(1280, 720);
                //string url = Uri.EscapeUriString("https://www.google.com/search?q=台積電&tbm=nws&start=0");
                //driver.Navigate().GoToUrl(url);

                int page_number = 1;
                int start_no = 0;
                string go_next = "Y";
                textBox2.Clear();
                while (go_next == "Y")
                {
                    start_no = (page_number - 1) * 10;
                    //string url = Uri.EscapeUriString("https://www.google.com/search?q=" + searchword + "&tbm=nws&Ccd_min:4/1/2020&Ccd_max:6/14/2020&start=" + start_no);
                    string url = Uri.EscapeUriString("https://www.google.com/search?q=" + searchword + "&tbm=nws&tbs=qdr:y&start=" + start_no);
                    driver.Navigate().GoToUrl(url);

                    //讀取"result status"
                    if (driver.PageSource.IndexOf("找不到符合") != -1)
                    {
                        go_next = "N";
                    }
                    else
                    {
                        write2text("===第" + page_number.ToString() + "頁===" + Environment.NewLine);
                        //寫入新聞資訊                    
                        string xpath_str = "";
                        IList<IWebElement> g = driver.FindElements(By.ClassName("g"));
                        write2text("===共" + g.Count.ToString() + "條===" + Environment.NewLine);
                        for (int i = 1; i <= g.Count; i++)
                        {
                            write2text("第" + i.ToString() + "條" + Environment.NewLine);
                            //title
                            xpath_str = "//*[@id='rso']/div[" + i + "]/div/div[1]/h3/a";
                            IWebElement a = driver.FindElement(By.XPath(xpath_str));
                            write2text("Title:" + a.Text + Environment.NewLine);
                            //link
                            write2text("link:" + a.GetAttribute("href") + Environment.NewLine);
                            //media
                            xpath_str = "//*[@id='rso']/div[" + i + "]/div/div[1]/div[1]/span[1]";
                            IWebElement a1 = driver.FindElement(By.XPath(xpath_str));
                            write2text("media:" + a1.Text + Environment.NewLine);
                            //pubdate
                            xpath_str = "//*[@id='rso']/div[" + i + "]/div/div[1]/div[1]/span[3]";
                            IWebElement a2 = driver.FindElement(By.XPath(xpath_str));
                            // 進行當日發布新聞日期調整
                            if (a2.Text.IndexOf("前") > -1)
                            {
                                write2text("date:" + DateTime.Today.ToString("yyyy年MM月dd日") + Environment.NewLine);
                            }
                            else
                            {
                                write2text("date:" + a2.Text + Environment.NewLine);
                            }
                            //desc
                            xpath_str = "//*[@id='rso']/div[" + i + "]/div/div/div[2]";
                            IWebElement a3 = driver.FindElement(By.XPath(xpath_str));
                            write2text("desc:" + a3.Text + Environment.NewLine + Environment.NewLine);

                            if (checkBox3.Checked)
                            {
                                //附掛新聞: YiHbdc
                                xpath_str = "//*[@id='rso']/div[" + i + "]";
                                IList<IWebElement> g1 = driver.FindElement(By.XPath(xpath_str)).FindElements(By.ClassName("YiHbdc"));
                                for (int j = 1; j <= g1.Count; j++)
                                {
                                    write2text("第" + i.ToString() + "條之 " + j.ToString() + Environment.NewLine);
                                    //title
                                    xpath_str = "//*[@id='rso']/div[" + i + "]/div/div[" + (j * 2) + "]/a";
                                    IWebElement card = driver.FindElement(By.XPath(xpath_str));
                                    write2text("Title:" + card.Text + Environment.NewLine);
                                    //link
                                    write2text("link:" + card.GetAttribute("href") + Environment.NewLine);
                                    //media
                                    xpath_str = "//*[@id='rso']/div[" + i + "]/div/div[" + (j * 2) + "]/span[1]";
                                    IWebElement card1 = driver.FindElement(By.XPath(xpath_str));
                                    write2text("media:" + card1.Text + Environment.NewLine);
                                    //pubdate
                                    xpath_str = "//*[@id='rso']/div[" + i + "]/div/div[" + (j * 2) + "]/span[3]";
                                    IWebElement card2 = driver.FindElement(By.XPath(xpath_str));
                                    // 進行當日發布新聞日期調整
                                    if (card2.Text.IndexOf("前") > -1)
                                    {
                                        write2text("date:" + DateTime.Today.ToString("yyyy年MM月dd日") + Environment.NewLine);
                                    }
                                    else
                                    {
                                        write2text("pubdate:" + card2.Text + Environment.NewLine);
                                    }
                                    //desc
                                    textBox2.AppendText("desc:" + card.Text + Environment.NewLine + Environment.NewLine);
                                }

                                //附掛新聞: ErI7Gd
                                xpath_str = "//*[@id='rso']/div[" + i + "]";
                                IList<IWebElement> g2 = driver.FindElement(By.XPath(xpath_str)).FindElements(By.ClassName("ErI7Gd"));
                                for (int k = 1; k <= g2.Count; k++)
                                {
                                    write2text("第" + i.ToString() + "條之 " + (k + g1.Count).ToString() + Environment.NewLine);
                                    //title
                                    xpath_str = "//*[@id='rso']/div[" + i + "]/div/div[" + ((k + g1.Count) * 2) + "]/a";
                                    IWebElement card = driver.FindElement(By.XPath(xpath_str));
                                    write2text("Title:" + card.Text + Environment.NewLine);
                                    //link
                                    write2text("link:" + card.GetAttribute("href") + Environment.NewLine);
                                    //media
                                    xpath_str = "//*[@id='rso']/div[" + i + "]/div/div[" + ((k + g1.Count) * 2) + "]/span[1]";
                                    IWebElement card1 = driver.FindElement(By.XPath(xpath_str));
                                    write2text("media:" + card1.Text + Environment.NewLine);
                                    //pubdate
                                    xpath_str = "//*[@id='rso']/div[" + i + "]/div/div[" + ((k + g1.Count) * 2) + "]/span[3]";
                                    IWebElement card2 = driver.FindElement(By.XPath(xpath_str));
                                    // 進行當日發布新聞日期調整
                                    if (card2.Text.IndexOf("前") > -1)
                                    {
                                        write2text("date:" + DateTime.Today.ToString("yyyy年MM月dd日") + Environment.NewLine);
                                    }
                                    else
                                    {
                                        write2text("pubdate:" + card2.Text + Environment.NewLine);
                                    }
                                    //desc
                                    write2text("desc:" + card.Text + Environment.NewLine);
                                }
                            }
                            //Application.DoEvents();
                        }
                        page_number++;
                        //go_next = "N"; 測試用
                    }
                };
                write2text("[" + searchword + "]查詢結束!!" + Environment.NewLine);
                Application.DoEvents();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                driver.Quit();
                driver.Dispose();
                Application.UseWaitCursor = false;
            }
            this.Cursor = Cursors.Default;

        }

        //查詢列表上傳
        private void button6_Click(object sender, EventArgs e)
        {
            var fileContent = string.Empty;
            var filePath = string.Empty;
            Microsoft.Office.Interop.Excel.Range dataRange = null;
            Microsoft.Office.Interop.Excel.Application xlApp1 = new Microsoft.Office.Interop.Excel.Application();

            try
            {
                //上傳公司名稱檔案,寫入searchtextbox
                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {
                    openFileDialog.InitialDirectory = "D:\\";
                    openFileDialog.Filter = "Excel檔案|*.xls;*.xlsx";
                    openFileDialog.FilterIndex = 0;
                    openFileDialog.RestoreDirectory = true;

                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        filePath = openFileDialog.FileName;
                        //改變鼠標樣式
                        this.Cursor = Cursors.WaitCursor;

                        Microsoft.Office.Interop.Excel.Workbook workbook = xlApp1.Workbooks.Open(filePath);
                        Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Worksheets[1]; //取得sheet1                  

                        for (int row = 1; row < worksheet.Rows.Count; row++)
                        {
                            dataRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[row, 1];
                            if (dataRange.Value2 != null)
                            {
                                //MessageBox.Show(dataRange.Value2.ToString());
                                if (fileContent == "")
                                {
                                    fileContent = dataRange.Value2.ToString() + ",";
                                }
                                else
                                {
                                    fileContent = fileContent + dataRange.Value2.ToString() + ",";
                                }
                                
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {                
                xlApp1.Quit();
                GC.Collect();//強行釋放
                MessageBox.Show(ex.ToString());
                this.Cursor = Cursors.Default; //還原預設
            }
            finally
            {
                SearchWord.Text = fileContent;
                xlApp1.Quit();
                GC.Collect();//強行釋放
                this.Cursor = Cursors.Default; //還原預設
            }
        }

        //顯示備註
        private void F_EsgNewsSearch_Shown(object sender, EventArgs e)
        {
            //get local release version info
            string release_version = ExtensionMethods.MyExtensions.ReadString("VERSION_CONTROL", "RELEASE_VERSION", "", dirstr);

            toolStripStatusLabel1.Text = "使用者：" + Environment.UserName;
            toolStripStatusLabel3.Text = toolStripStatusLabel1.Text ;
            toolStripStatusLabel5.Text = "";
            toolStripStatusLabel6.Text = toolStripStatusLabel5.Text ;
            toolStripStatusLabel7.Text = "版本:" + release_version;
            toolStripStatusLabel8.Text = toolStripStatusLabel7.Text;

            timer1.Interval = 1000;
            timer1.Enabled = true; //計時用

            if (SearchWord.Text == "")
            {
                SearchWord.Init("輸入公司名稱:如日產+高恩,台積電 公司請用','分隔;複合關鍵字請用'+'串聯");
            }            
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox4.SelectedIndex)
            {
                case 0:
                    checkBox3.Visible = false ;
                    break;
                default:
                    checkBox3.Checked = false;
                    checkBox3.Visible = true ;
                    break;
            }

        }

        //判斷中文字
        public static bool isChinese(string strChinese)
        {
            bool bresult = true;
            int dRange = 0;
            int dstringmax = Convert.ToInt32("9fff", 16);
            int dstringmin = Convert.ToInt32("4e00", 16);
            for (int i = 0; i < strChinese.Length; i++)
            {
                dRange = Convert.ToInt32(Convert.ToChar(strChinese.Substring(i, 1)));
                if (dRange >= dstringmin && dRange < dstringmax)
                {
                    bresult = true;
                    break;
                }
                else
                {
                    bresult = false;
                }
            }

            return bresult;
        }

        //批量查詢精選100
        private void button7_Click(object sender, EventArgs e)
        {
            //參數宣告
            //建立 PhantomJS
            IWebDriver driver = new PhantomJSDriver(GetPhantomJSDriverService());
            Random random = new Random(Guid.NewGuid().GetHashCode()); //原理是利用Guid.NewGuid()每一次所產生出來的結果都是不同的，再利用它產生雜湊碼來當成亂數產生器的種子，產生出真的很亂的亂數。

            string tmpdt = "", tmpttl = "";
            int ran_record = 0;
            string after_day = ""; //查詢起始日
            string before_day = ""; //查詢截止日
            string NewsParameters = ""; //查詢關鍵字
            string NewsParameters_ID = ""; //查詢關鍵字ID
            string lang = "";
            int keyoption = 0; //
            string period = "";

            string match_title_ = "", match_keyword = "", match_kword = "";
            string lng_negative = "", lng_governance = "", lng_Environmental = "", lng_social = "";

            //ESG檢查負面關鍵字
            string negative = "";

            tabControl1.SelectedIndex = 0;
            //符合負面關鍵字詞數量
            int match_cnt = 0;

            //符合複合關鍵字的新聞 flag
            string go_match_keyword = "N";

            //命中負面關鍵字詞筆數
            int match_Recordcount = 0;

            //讀取負面關鍵字預設值
            StringBuilder data = new StringBuilder(255);          

            // 讀取查詢名單    
            List<String> Checklist = new List<String>();
            Checklist = SearchWord.Text.Split(',').ToList();

            // 網站查詢
            try
            {
                this.Cursor = Cursors.WaitCursor;
                //傳送網址
                string url = "";
                string RealSearchWord = "";
                float CheckCnt = 0 ;

                //查詢關鍵字迴圈
                foreach (String NewsParameters_ALL in Checklist)
                {
                    CheckCnt = CheckCnt + 1;
                    //若有空字串不查
                    NewsParameters = NewsParameters_ALL.Substring(NewsParameters_ALL.IndexOf("]")+1, NewsParameters_ALL.Length- NewsParameters_ALL.IndexOf("]")-1) ;//查詢關鍵字
                    NewsParameters_ID = NewsParameters_ALL.Substring(NewsParameters_ALL.IndexOf("[") + 1, NewsParameters_ALL.IndexOf("]")-1);//查詢關鍵字ID


                    //判斷使用繁體-中文還是英文
                    lang = "台灣-中文";

                    //判斷單筆關鍵詞是純英文否                    
                    if (isChinese(NewsParameters))
                    {
                        lang = "台灣-中文";
                    }
                    else
                    {
                        lang = "美國-英文";
                    }

                    //查詢關鍵字有值才檢查
                    if (NewsParameters.Trim().ToString() != "")
                    {
                        //是否繼續查詢標記
                        if (go_flag == "Y")
                        {
                            //傳送關鍵字-0.包含;1.完整
                            switch (keyoption)
                            {
                                case 0:
                                    RealSearchWord = System.Net.WebUtility.UrlEncode(NewsParameters);
                                    break;
                                case 1:
                                    RealSearchWord = System.Net.WebUtility.UrlEncode("\"" + NewsParameters + "\"");
                                    break;
                            }

                            //設定時間變數
                            string Newperiod = "";
                            if (period == "過去24小時")
                            { Newperiod = " when:1d"; }
                            else if (period == "過去7天")
                            { Newperiod = " when:7d"; }
                            else if (period == "過去30天")
                            { Newperiod = " when:30d"; }
                            else if (period == "過去90天")
                            { Newperiod = " when:90d"; }
                            else if (period == "過去1年")
                            { Newperiod = " when:1y"; }
                            else if (period == "不限時間")
                            { Newperiod = ""; }

                            //選擇查詢國家
                            //指定查詢區間
                            Newperiod = " after:2019/9/30 before:2020/9/30";

                            if (lang == "中國-中文")
                            {
                                url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=zh-CN&gl=CN&ceid=CN:zh-Hans";
                            }
                            else if (lang == "香港-中文")
                            {
                                url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=zh-HK&gl=HK&ceid=HK:zh-Hant";
                            }
                            else if (lang == "美國-英文")
                            {
                                url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=en-US&gl=US&ceid=US:en";
                            }
                            else if (lang == "日本-日文")
                            {
                                url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=ja&gl=JP&ceid=JP:ja";
                            }
                            else //台灣-中文
                            {
                                //網址轉碼
                                //url = Uri.EscapeUriString(url);
                                url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=zh-TW&gl=TW&ceid=TW:zh-Hant";
                            }

                            tb_url.Text = url;
                            toolStripStatusLabel5.Text = url;
                            toolStripStatusLabel6.Text = toolStripStatusLabel5.Text;
                            Application.DoEvents();

                            //前往查詢網址
                            driver.Navigate().GoToUrl(url);

                            List<ItemNews> Detail = new List<ItemNews>();

                            //Declare Dataset for putting data in it.
                            DataSet ds = new DataSet();
                            StringReader reader = new StringReader(driver.PageSource);
                            ds.ReadXml(reader);
                            System.Data.DataTable dtGetNews = new System.Data.DataTable();

                            int cnt = 1;
                            //開始查詢第一個公司
                            write2text("==" + comboBox3.Text + "== " + NewsParameters + " =====");

                            if (ds.Tables.Count > 3)
                            {
                                dtGetNews = ds.Tables["item"];

                                //寫入XML離線資料
                                foreach (DataRow dtRow in dtGetNews.Rows)
                                {
                                    //寫入google news 回訊
                                    ItemNews DataObj = new ItemNews();
                                    DataObj.searchword = NewsParameters;
                                    DataObj.searchword_ID = NewsParameters_ID ;
                                    DataObj.title = dtRow["title"].ToString();
                                    DataObj.link = dtRow["link"].ToString();
                                    DataObj.item_id = dtRow["item_id"].ToString();
                                    DataObj.PubDate = dtRow["pubDate"].ToString();
                                    DataObj.Description = dtRow["description"].ToString();
                                    DataObj.Source = DataObj.title.Substring(DataObj.title.LastIndexOf(" - ") + 3);
                                    Detail.Add(DataObj);
                                    write2text(cnt.ToString() + ": " + "[" + DataObj.searchword + "]--" + DataObj.PubDate + "," + DataObj.Source + "," + DataObj.title);

                                    //寫入 dataset 
                                    if (DataObj.PubDate != "")
                                    {
                                        // DataGrid
                                        //drNews建立資料集Row
                                        DataRow drNews;
                                        DateTime oDate = Convert.ToDateTime(DataObj.PubDate);
                                        drNews = dtGoogleNews.NewRow();
                                        drNews["date_"] = "20200930";
                                        drNews["search_id_"] = DataObj.searchword_ID;
                                        drNews["search_nm_"] = DataObj.searchword;
                                        drNews["title_"] = DataObj.title;
                                        drNews["link_"] = DataObj.link;
                                        if (DataObj.PubDate != "")
                                        { drNews["pub_date_"] = oDate.Year.ToString("0000") + "年" + oDate.Month.ToString("00") + "月" + oDate.Day.ToString("00") + "日"; }
                                        else
                                        { drNews["pub_date_"] = DateTime.Today.Year.ToString("0000") + "年" + DateTime.Today.Month.ToString("00") + "月" + DateTime.Today.Day.ToString("00") + "日"; }
                                        drNews["desc_"] = DataObj.Description;
                                        drNews["media_"] = DataObj.Source;
                                        drNews["weight_"] = 0;
                                        drNews["match_word"] = "";
                                        drNews["lang_"] = lang ;
                                        dtGoogleNews.Rows.Add(drNews);
                                    }
                                    cnt++;
                                }
                                //完成查詢
                                write2text("===== 查詢結束 ===== " + DateTime.Now.ToString());
                            }
                            else
                            {
                                write2text("===== 查無符合新聞 ===== " + DateTime.Now.ToString());
                            }
                            //if (ds.Tables.Count > 3)

                            //增加查詢暫緩時間 random 
                            //當查詢到800筆時,休息10分鐘
                            int number1 = 0;
                            bool canConvert = Int32.TryParse((CheckCnt / 1000.00).ToString(), out number1);
                            if (canConvert == true)
                            {
                                ran_record = random.Next(8, 13);
                                Thread.Sleep(ran_record * 60 * 1000); //1000為一秒 / 60 *1000為60秒
                            }

                        }
                    }
                }
                dtGoogleNews.AcceptChanges();
                //查詢關鍵字迴圈

                //ESG檢查負面關鍵字
                //BAD WORD

                //處理複合關鍵字
                write2text("===== 負面關鍵字檢查開始 ===== " + DateTime.Now.ToString());

                //遍歷原始新聞資料集
                int total_cnt = dtGoogleNews.Rows.Count - 1;

                for (int i = total_cnt; i >= 0; i--)
                {
                    match_cnt = 0;
                    //資料內容轉換繁體或簡體
                    List<String> KeywordList = new List<String>();
                    KeywordList.Clear();
                    negative = "" ;
                    lang = dtGoogleNews.Rows[i]["lang_"].ToString();

                    if (lang == "美國-英文") // 英文轉換統一大寫
                    {
                        lng_negative = "en_negative";
                        lng_governance = "en_governance";
                        lng_Environmental = "en_Environmental";
                        lng_social = "en_social";

                        if (negative.Length == 0)
                        { negative = ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_negative, "", dirstr); }
                        else
                        { negative = negative + "," + ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_negative, "", dirstr); }

                        //Governance
                        if (negative.Length == 0)
                        { negative = ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_governance, "", dirstr); }
                        else
                        { negative = negative + "," + ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_governance, "", dirstr); }

                        //Environmental
                        if (negative.Length == 0)
                        { negative = ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_Environmental, "", dirstr); }
                        else
                        { negative = negative + "," + ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_Environmental, "", dirstr); }

                        //social
                        if (negative.Length == 0)
                        { negative = ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_social, "", dirstr); }
                        else
                        { negative = negative + "," + ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_social, "", dirstr); }


                        if (negative.Trim().Length > 0)
                        { KeywordList = negative.Split(',').ToList(); }

                        match_title_ = dtGoogleNews.Rows[i]["title_"].ToString().ToUpper();
                        match_keyword = dtGoogleNews.Rows[i]["search_nm_"].ToString().ToUpper();
                    }
                    else // 繁體
                    {
                        lng_negative = "zh_negative";
                        lng_governance = "zh_governance";
                        lng_Environmental = "zh_Environmental";
                        lng_social = "zh_social";

                        if (negative.Length == 0)
                        { negative = ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_negative, "", dirstr); }
                        else
                        { negative = negative + "," + ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_negative, "", dirstr); }

                        //Governance
                        if (negative.Length == 0)
                        { negative = ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_governance, "", dirstr); }
                        else
                        { negative = negative + "," + ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_governance, "", dirstr); }

                        //Environmental
                        if (negative.Length == 0)
                        { negative = ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_Environmental, "", dirstr); }
                        else
                        { negative = negative + "," + ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_Environmental, "", dirstr); }

                        //social
                        if (negative.Length == 0)
                        { negative = ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_social, "", dirstr); }
                        else
                        { negative = negative + "," + ExtensionMethods.MyExtensions.ReadString("ESG_NG_WORD", lng_social, "", dirstr); }


                        if (negative.Trim().Length > 0)
                        { KeywordList = negative.Split(',').ToList(); }

                        match_title_ = ConvertChinese(dtGoogleNews.Rows[i]["title_"].ToString().ToUpper(), CharsetType.Traditional);
                        match_keyword = ConvertChinese(dtGoogleNews.Rows[i]["search_nm_"].ToString().ToUpper(), CharsetType.Traditional);
                    }

                    go_match_keyword = "N";

                    List<String> ls_match_keyword = new List<String>();
                    ls_match_keyword = match_keyword.Split('+').ToList();
                    foreach (string mkeyword in ls_match_keyword)
                    {
                        if (match_title_.IndexOf(mkeyword) != -1)
                        {
                            go_match_keyword = "Y";
                        }
                    }

                    //當新聞title 包含複合關鍵字時 saved or remove
                    if (go_match_keyword == "Y")
                    {
                        //MessageBox.Show(match_keyword + Environment.NewLine
                        //                                   + match_title_);
                        //比對符合多少負面關鍵字
                        foreach (string kword in KeywordList)
                        {
                            if (lang == "美國-英文") // 英文轉換統一大寫
                            {
                                match_kword = kword;
                            }
                            else// 繁體
                            {
                                match_kword = ConvertChinese(kword, CharsetType.Traditional);
                            }

                            if (match_kword.Trim().ToString() != "")
                            {
                                bool v_go;
                                //移除掉非文字字元
                                match_title_ = Regex.Replace(match_title_, @"[^\w\.@-]", " ", RegexOptions.None, TimeSpan.FromSeconds(1.5));

                                if (lang == "美國-英文") // 英文轉換統一大寫
                                {
                                    v_go = Regex.IsMatch(match_title_, string.Format(@"\b{0}\b", match_kword), RegexOptions.IgnoreCase);
                                }
                                else //中文
                                {
                                    v_go = match_title_.Contains(match_kword);
                                }

                                if (v_go)
                                {
                                    match_cnt = match_cnt + 1;
                                    if (dtGoogleNews.Rows[i]["match_word"] == "")
                                    { dtGoogleNews.Rows[i]["match_word"] = match_kword; }
                                    else
                                    { dtGoogleNews.Rows[i]["match_word"] = dtGoogleNews.Rows[i]["match_word"] + "," + match_kword; }

                                }
                            }
                        }
                        // 無負面關鍵字
                        if (match_cnt == 0)
                        {
                            //MessageBox.Show("NoMatch:" + match_cnt.ToString() +":" + match_title_ );
                            //dtGoogleNews.Rows[i].Delete();                                
                        }
                        else
                        {
                            match_Recordcount = match_Recordcount + 1;
                            dtGoogleNews.Rows[i]["weight_"] = match_cnt;
                            //MessageBox.Show("Match:" + match_cnt.ToString() + ":"  + match_title_  ); 
                        }
                    }
                    else
                    {
                        //delete no match keyword record
                        //dtGoogleNews.Rows[i].Delete();
                    }
                }
                //遍歷原始新聞資料集
                dtGoogleNews.AcceptChanges();
                write2text("===== 負面關鍵字檢查結束 ===== " + DateTime.Now.ToString());
                write2text("===== 轉寫資料庫開始 ===== " + DateTime.Now.ToString());
                String DestinationTableName = "EsgNewsDetail";

                //刪除資料庫資料
                //SqlCommand sqlComm = new SqlCommand();
                //sqlComm.Connection = cnn;
                //sqlComm.CommandText = "DELETE FROM dbo." + DestinationTableName + "  WHERE 1 = 1 ";
                //sqlComm.ExecuteNonQuery();

                //批量寫入資料mssql                            
                //3. 使用 sqlBulkCopy寫入 SQL資料表
                //using (System.Data.SqlClient.SqlBulkCopy bcp = new System.Data.SqlClient.SqlBulkCopy(connectionString, SqlBulkCopyOptions.UseInternalTransaction))
                //{
                //    //bcp.SqlRowsCopied += new System.Data.SqlClient.SqlRowsCopiedEventHandler(bcp_SqlRowsCopied);
                //    bcp.BatchSize = 1000; //每次傳輸行數
                //    bcp.NotifyAfter = 100; //進度提示的行數
                //    bcp.DestinationTableName = DestinationTableName; //目標table 
                //    bcp.WriteToServer(dtGoogleNews); //轉寫入MSSQL
                //}

                //sqlComm.Dispose();
                dtGoogleNews.Dispose();

                write2text("===== 轉寫資料庫完成 ===== " + DateTime.Now.ToString());
                if (dtGoogleNews.Rows.Count == 0)
                {
                    if (textBox2.Text.IndexOf("偵測為自動化程式, 暫緩使用") == -1)
                    {
                        MessageBox.Show("查無符合新聞資訊");
                    }
                }
                else
                {
                    MessageBox.Show("檢視新聞共 " + dtGoogleNews.Rows.Count.ToString("#,0") + " 筆"
                                   + Environment.NewLine
                                   + "符合負面新聞共 " + match_Recordcount.ToString("#,0") + " 筆");
                    tabControl1.SelectedIndex = 1;
                }

            }
            catch (Exception ex )
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("查詢錯誤,請稍侯再查詢 !!" + Environment.NewLine
                                + ex.ToString() + Environment.NewLine
                                );
                go_flag = "N"; //停止後續作業
            }
            finally
            {
                this.Cursor = Cursors.Default;
                driver.Close();
                driver.Dispose();
                go_flag = "Y"; //停止後續作業
            }
                // 網站查詢
            // 判斷單筆關鍵詞是純英文否
            // 網站查詢
            // 寫入dataGrid
            // 負面關鍵字檢查
            // 結束查詢迴圈
            // 寫入資料庫
        }

        private void label4_DoubleClick(object sender, EventArgs e)
        {
            if (label7.Visible)
            {
                label7.Visible = false;
                comboBox4.Visible = false;
                tb_url.Visible = false;
            }
            else
            {
                label7.Visible = true;
                comboBox4.Visible = true;
                tb_url.Visible = true;
            }

        }

        //填入即時時間
        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel4.Text = DateTime.Now.ToString();
            toolStripStatusLabel2.Text = toolStripStatusLabel4.Text;
        }


    }
}
